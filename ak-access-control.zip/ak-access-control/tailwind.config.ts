/**
 * tailwind.config.ts — AK Access Control
 *
 * Project uses Tailwind CSS v4 via @tailwindcss/vite plugin.
 *
 * NOTE: In Tailwind v4, most configuration (colors, fonts, radius) is
 * handled directly in CSS using @theme inside index.css.
 * This file handles content paths, plugins, and any legacy overrides
 * needed for shadcn/ui components in the mockup-sandbox / web dashboard.
 *
 * Stack:
 *   - Tailwind CSS v4 (catalog: ^4.1.14)
 *   - @tailwindcss/vite plugin (no PostCSS needed)
 *   - shadcn/ui (new-york style, neutral base, CSS variables)
 *   - tw-animate-css for animation utilities
 *   - tailwindcss-animate for shadcn animation support
 *
 * Theme colors (from design reference — golden yellow palette):
 *   Primary accent : #FBBF24  (golden yellow)
 *   Background     : #0A0A0A  (deep black)
 *   Surface        : #141414
 *   Surface raised : #1C1C1C
 *   Border         : #2A2A2A
 *   Text primary   : #FFFFFF
 *   Text secondary : #8E8E93
 *   Success        : #30D158
 *   Warning        : #FFD60A
 *   Danger         : #FF453A
 */

import type { Config } from "tailwindcss";
import animate from "tailwindcss-animate";

const config: Config = {
  // ── Dark mode via .dark class (matches index.css) ──────────────────────────
  darkMode: ["class"],

  // ── Content paths ──────────────────────────────────────────────────────────
  // Covers all packages in the monorepo that use Tailwind classes
  content: [
    // Web dashboard (mockup-sandbox)
    "./src/**/*.{ts,tsx,js,jsx}",
    "./index.html",

    // Shared UI components (shadcn/ui)
    "../../lib/**/*.{ts,tsx}",

    // Any other artifacts that render HTML/JSX
    "../**/*.{ts,tsx,js,jsx,html}",
  ],

  theme: {
    extend: {
      // ── Colors — mirrors CSS variables in index.css ───────────────────────
      // These allow Tailwind utilities like bg-primary, text-accent, etc.
      colors: {
        // shadcn/ui semantic tokens (bound to CSS variables)
        background:   "hsl(var(--background))",
        foreground:   "hsl(var(--foreground))",
        border:       "hsl(var(--border))",
        input:        "hsl(var(--input))",
        ring:         "hsl(var(--ring))",

        primary: {
          DEFAULT:    "hsl(var(--primary))",
          foreground: "hsl(var(--primary-foreground))",
        },
        secondary: {
          DEFAULT:    "hsl(var(--secondary))",
          foreground: "hsl(var(--secondary-foreground))",
        },
        destructive: {
          DEFAULT:    "hsl(var(--destructive))",
          foreground: "hsl(var(--destructive-foreground))",
        },
        muted: {
          DEFAULT:    "hsl(var(--muted))",
          foreground: "hsl(var(--muted-foreground))",
        },
        accent: {
          DEFAULT:    "hsl(var(--accent))",
          foreground: "hsl(var(--accent-foreground))",
        },
        popover: {
          DEFAULT:    "hsl(var(--popover))",
          foreground: "hsl(var(--popover-foreground))",
        },
        card: {
          DEFAULT:    "hsl(var(--card))",
          foreground: "hsl(var(--card-foreground))",
        },

        // Sidebar tokens
        sidebar: {
          DEFAULT:            "hsl(var(--sidebar))",
          foreground:         "hsl(var(--sidebar-foreground))",
          primary:            "hsl(var(--sidebar-primary))",
          "primary-foreground": "hsl(var(--sidebar-primary-foreground))",
          accent:             "hsl(var(--sidebar-accent))",
          "accent-foreground": "hsl(var(--sidebar-accent-foreground))",
          border:             "hsl(var(--sidebar-border))",
          ring:               "hsl(var(--sidebar-ring))",
        },

        // Chart tokens
        chart: {
          "1": "hsl(var(--chart-1))",
          "2": "hsl(var(--chart-2))",
          "3": "hsl(var(--chart-3))",
          "4": "hsl(var(--chart-4))",
          "5": "hsl(var(--chart-5))",
        },

        // ── AK Access Control brand tokens ───────────────────────────────
        // Use these directly: bg-ak-yellow, text-ak-surface, etc.
        ak: {
          // Golden yellow — primary action color
          yellow:         "#FBBF24",
          "yellow-dark":  "#D97706",
          "yellow-glow":  "rgba(251,191,36,0.18)",
          "yellow-border":"rgba(251,191,36,0.35)",

          // Dark backgrounds
          bg:             "#0A0A0A",
          surface:        "#141414",
          "surface-raised":"#1C1C1C",
          border:         "#2A2A2A",

          // Text
          "text-primary":   "#FFFFFF",
          "text-secondary": "#8E8E93",
          "text-tertiary":  "#48484A",

          // Status colors (match Colors.ts in gym-app)
          success:  "#30D158",
          warning:  "#FFD60A",
          danger:   "#FF453A",
          "danger-soft": "rgba(255,69,58,0.12)",
        },
      },

      // ── Border Radius — matches index.css --radius variable ───────────────
      borderRadius: {
        lg:   "var(--radius)",
        md:   "calc(var(--radius) - 2px)",
        sm:   "calc(var(--radius) - 4px)",
        xl:   "calc(var(--radius) + 4px)",
        "2xl":"calc(var(--radius) + 8px)",
      },

      // ── Typography ────────────────────────────────────────────────────────
      fontFamily: {
        sans:  ["Inter", "sans-serif"],
        serif: ["Georgia", "serif"],
        mono:  ["Menlo", "monospace"],
      },

      // ── Spacing ───────────────────────────────────────────────────────────
      spacing: {
        "18": "4.5rem",
        "22": "5.5rem",
        "88": "22rem",
        "112":"28rem",
        "128":"32rem",
      },

      // ── Keyframe Animations (for shadcn/ui + tw-animate-css) ─────────────
      keyframes: {
        // shadcn accordion
        "accordion-down": {
          from: { height: "0" },
          to:   { height: "var(--radix-accordion-content-height)" },
        },
        "accordion-up": {
          from: { height: "var(--radix-accordion-content-height)" },
          to:   { height: "0" },
        },

        // Fade in (used on login screen logo, dashboard cards)
        "fade-in": {
          from: { opacity: "0", transform: "translateY(8px)" },
          to:   { opacity: "1", transform: "translateY(0)" },
        },

        // Pulse glow — for the yellow accent badge / logo
        "glow-pulse": {
          "0%, 100%": {
            boxShadow: "0 0 12px 2px rgba(251,191,36,0.3)",
          },
          "50%": {
            boxShadow: "0 0 24px 6px rgba(251,191,36,0.55)",
          },
        },

        // Shake — for wrong PIN / login error feedback on web
        shake: {
          "0%, 100%": { transform: "translateX(0)" },
          "10%, 50%, 90%": { transform: "translateX(-8px)" },
          "30%, 70%": { transform: "translateX(8px)" },
        },

        // Live feed pulse dot (dashboard real-time indicator)
        "live-dot": {
          "0%, 100%": { opacity: "1", transform: "scale(1)" },
          "50%":      { opacity: "0.4", transform: "scale(0.75)" },
        },

        // Slide in from bottom (modals, bottom sheets)
        "slide-up": {
          from: { opacity: "0", transform: "translateY(16px)" },
          to:   { opacity: "1", transform: "translateY(0)" },
        },
      },

      // ── Animation utilities ───────────────────────────────────────────────
      animation: {
        "accordion-down": "accordion-down 0.2s ease-out",
        "accordion-up":   "accordion-up 0.2s ease-out",
        "fade-in":        "fade-in 0.5s ease-out both",
        "glow-pulse":     "glow-pulse 2.5s ease-in-out infinite",
        "shake":          "shake 0.4s ease-in-out",
        "live-dot":       "live-dot 1.5s ease-in-out infinite",
        "slide-up":       "slide-up 0.3s ease-out both",
      },

      // ── Box Shadows — AK brand glow effects ───────────────────────────────
      boxShadow: {
        "ak-yellow":  "0 0 20px rgba(251,191,36,0.35)",
        "ak-yellow-lg":"0 4px 32px rgba(251,191,36,0.4)",
        "ak-surface": "0 2px 16px rgba(0,0,0,0.6)",
        "ak-card":    "0 1px 4px rgba(0,0,0,0.4)",
      },
    },
  },

  // ── Plugins ───────────────────────────────────────────────────────────────
  plugins: [
    // Required for shadcn/ui animation utilities
    animate,
  ],
};

export default config;
