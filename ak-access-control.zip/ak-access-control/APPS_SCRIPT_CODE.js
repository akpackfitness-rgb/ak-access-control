// ============================================================
//  GYM ATTENDANCE MANAGER — Google Apps Script
//  Paste this entire file into your Google Sheet's Script Editor:
//  Extensions → Apps Script → Replace everything → Save → Deploy
//
//  REQUIRED SHEET NAMES:
//    "Members"    — columns: Membership ID, Name, Phone, Email,
//                            Package, Start Date, Expiry Date
//    "Attendance" — columns: ID, Membership ID, Member Name,
//                            Package, Type, Timestamp, Status,
//                            Days Until Expiry
// ============================================================

var MEMBERS_SHEET = "Members";
var ATTENDANCE_SHEET = "Attendance";

// ---- Entry Points ------------------------------------------

function doGet(e) {
  var action = e && e.parameter && e.parameter.action;
  var result;

  try {
    if (action === "getAllMembers") {
      result = getAllMembers();
    } else if (action === "getMember") {
      var membershipId = e.parameter.membershipId;
      result = getMember(membershipId);
    } else if (action === "getAttendance") {
      var limit = parseInt(e.parameter.limit) || 50;
      result = getAttendance(limit);
    } else {
      result = { status: "error", message: "Unknown action: " + action };
    }
  } catch (err) {
    result = { status: "error", message: err.toString() };
  }

  return ContentService
    .createTextOutput(JSON.stringify(result))
    .setMimeType(ContentService.MimeType.JSON);
}

function doPost(e) {
  var action = e && e.parameter && e.parameter.action;
  var result;

  try {
    var body = {};
    if (e.postData && e.postData.contents) {
      body = JSON.parse(e.postData.contents);
    }

    if (action === "logAttendance") {
      result = logAttendance(body);
    } else {
      result = { status: "error", message: "Unknown action: " + action };
    }
  } catch (err) {
    result = { status: "error", message: err.toString() };
  }

  return ContentService
    .createTextOutput(JSON.stringify(result))
    .setMimeType(ContentService.MimeType.JSON);
}

// ---- Helpers -----------------------------------------------

function getSheet(name) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sheet = ss.getSheetByName(name);
  if (!sheet) throw new Error("Sheet '" + name + "' not found");
  return sheet;
}

function sheetToObjects(sheet) {
  var data = sheet.getDataRange().getValues();
  if (data.length < 2) return [];
  var headers = data[0].map(function(h) { return String(h).trim(); });
  return data.slice(1).map(function(row) {
    var obj = {};
    headers.forEach(function(h, i) {
      obj[h] = row[i] !== undefined && row[i] !== null ? String(row[i]).trim() : "";
    });
    return obj;
  });
}

// ---- Actions -----------------------------------------------

function getAllMembers() {
  var sheet = getSheet(MEMBERS_SHEET);
  var members = sheetToObjects(sheet);
  return members.map(normalizeMember);
}

function getMember(membershipId) {
  if (!membershipId) throw new Error("membershipId is required");
  var sheet = getSheet(MEMBERS_SHEET);
  var members = sheetToObjects(sheet);
  var found = members.find(function(m) {
    return String(m["Membership ID"] || m["MembershipID"] || m["membershipId"] || "")
      .trim().toLowerCase() === String(membershipId).trim().toLowerCase();
  });
  if (!found) return { status: "error", message: "Member not found" };
  return normalizeMember(found);
}

function getAttendance(limit) {
  var sheet = getSheet(ATTENDANCE_SHEET);
  var rows = sheetToObjects(sheet);
  // Return most recent first
  rows.reverse();
  if (limit && rows.length > limit) rows = rows.slice(0, limit);
  return rows.map(function(r) {
    return {
      id:              r["ID"] || r["id"] || "",
      membershipId:    r["Membership ID"] || r["MembershipID"] || r["membershipId"] || "",
      memberName:      r["Member Name"] || r["MemberName"] || r["memberName"] || "",
      package:         r["Package"] || r["package"] || "",
      type:            (r["Type"] || r["type"] || "entry").toLowerCase(),
      timestamp:       r["Timestamp"] || r["timestamp"] || "",
      status:          r["Status"] || r["status"] || "active",
      daysUntilExpiry: parseInt(r["Days Until Expiry"] || r["DaysUntilExpiry"] || r["daysUntilExpiry"] || "0") || 0
    };
  });
}

function logAttendance(data) {
  var sheet = getSheet(ATTENDANCE_SHEET);

  // Create header row if sheet is empty
  if (sheet.getLastRow() === 0) {
    sheet.appendRow([
      "ID", "Membership ID", "Member Name", "Package",
      "Type", "Timestamp", "Status", "Days Until Expiry"
    ]);
  }

  sheet.appendRow([
    data.id              || Utilities.getUuid(),
    data.membershipId    || "",
    data.memberName      || "",
    data.package         || "",
    data.type            || "entry",
    data.timestamp       || new Date().toISOString(),
    data.status          || "active",
    data.daysUntilExpiry !== undefined ? data.daysUntilExpiry : 0
  ]);

  return { status: "ok" };
}

// ---- Normalizer --------------------------------------------

function normalizeMember(row) {
  return {
    membershipId: row["Membership ID"] || row["MembershipID"] || row["membershipId"] || "",
    name:         row["Name"]          || row["name"]         || "",
    phone:        row["Phone"]         || row["phone"]        || "",
    email:        row["Email"]         || row["email"]        || "",
    package:      row["Package"]       || row["package"]      || row["Package Name"] || "",
    startDate:    row["Start Date"]    || row["StartDate"]    || row["startDate"]    || "",
    expiryDate:   row["Expiry Date"]   || row["ExpiryDate"]   || row["expiryDate"]   || ""
  };
}
