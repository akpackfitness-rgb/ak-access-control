const primary = "#FF3B30";
const primaryDark = "#CC2E25";
const accent = "#FF6B35";
const background = "#0A0A0A";
const surface = "#141414";
const surfaceElevated = "#1C1C1C";
const surfaceBorder = "#2A2A2A";
const textPrimary = "#FFFFFF";
const textSecondary = "#8E8E93";
const textTertiary = "#48484A";
const success = "#30D158";
const warning = "#FFD60A";
const danger = "#FF453A";

export default {
  primary,
  primaryDark,
  accent,
  background,
  surface,
  surfaceElevated,
  surfaceBorder,
  textPrimary,
  textSecondary,
  textTertiary,
  success,
  warning,
  danger,
  light: {
    text: textPrimary,
    background,
    tint: primary,
    tabIconDefault: textTertiary,
    tabIconSelected: primary,
  },
};
