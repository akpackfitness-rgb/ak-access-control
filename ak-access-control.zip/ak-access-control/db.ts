import { pool } from "@workspace/db";

export async function initDb() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS attendance_logs (
      id TEXT PRIMARY KEY,
      membership_id TEXT NOT NULL,
      member_name TEXT NOT NULL,
      package TEXT,
      type TEXT NOT NULL CHECK (type IN ('entry', 'exit')),
      timestamp TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      status TEXT NOT NULL DEFAULT 'active',
      days_until_expiry INTEGER NOT NULL DEFAULT 0,
      date_key TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_attendance_date ON attendance_logs(date_key);
    CREATE INDEX IF NOT EXISTS idx_attendance_member ON attendance_logs(membership_id, date_key);
  `);
  console.log("Attendance DB table ready");
}

export async function insertAttendance(record: {
  id: string;
  membershipId: string;
  memberName: string;
  package: string;
  type: "entry" | "exit";
  timestamp: string;
  status: string;
  daysUntilExpiry: number;
}) {
  const dateKey = record.timestamp.slice(0, 10);
  await pool.query(
    `INSERT INTO attendance_logs
       (id, membership_id, member_name, package, type, timestamp, status, days_until_expiry, date_key)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
     ON CONFLICT (id) DO NOTHING`,
    [
      record.id,
      record.membershipId,
      record.memberName,
      record.package,
      record.type,
      record.timestamp,
      record.status,
      record.daysUntilExpiry,
      dateKey,
    ]
  );
}

export async function getAttendanceByDate(dateKey: string, limit = 100) {
  const res = await pool.query(
    `SELECT * FROM attendance_logs WHERE date_key = $1 ORDER BY timestamp DESC LIMIT $2`,
    [dateKey, limit]
  );
  return res.rows;
}

export async function getTodayEntryForMember(membershipId: string, dateKey: string) {
  const res = await pool.query(
    `SELECT * FROM attendance_logs
     WHERE membership_id = $1 AND date_key = $2 AND type = 'entry'
     ORDER BY timestamp DESC LIMIT 1`,
    [membershipId, dateKey]
  );
  return res.rows[0] || null;
}

export async function getTodayExitForMember(membershipId: string, dateKey: string) {
  const res = await pool.query(
    `SELECT * FROM attendance_logs
     WHERE membership_id = $1 AND date_key = $2 AND type = 'exit'
     ORDER BY timestamp DESC LIMIT 1`,
    [membershipId, dateKey]
  );
  return res.rows[0] || null;
}

export async function getAvailableDates() {
  const res = await pool.query(
    `SELECT DISTINCT date_key FROM attendance_logs ORDER BY date_key DESC LIMIT 60`
  );
  return res.rows.map((r: any) => r.date_key as string);
}
