import React, { useState, useRef, useCallback, useEffect } from "react";
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  FlatList,
  Pressable,
  ActivityIndicator,
  Platform,
  KeyboardAvoidingView,
  ScrollView,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Feather, MaterialCommunityIcons } from "@expo/vector-icons";
import { fetch as expoFetch } from "expo/fetch";
import Colors from "@/constants/colors";
import * as Haptics from "expo-haptics";

const BASE_URL = process.env.EXPO_PUBLIC_DOMAIN
  ? `https://${process.env.EXPO_PUBLIC_DOMAIN}`
  : "";

type Message = {
  id: string;
  role: "user" | "assistant";
  content: string;
};

type FitnessLevel = "beginner" | "intermediate" | "advanced";

const QUICK_PROMPTS = [
  "Create a 3-day beginner workout plan",
  "How do I build core strength?",
  "Best exercises for weight loss",
  "What should I eat before working out?",
  "Create a full body workout for home",
  "How to improve my cardio endurance?",
];

const LEVEL_OPTIONS: Array<{ value: FitnessLevel; label: string; icon: string }> = [
  { value: "beginner", label: "Beginner", icon: "seedling" },
  { value: "intermediate", label: "Intermediate", icon: "trending-up" },
  { value: "advanced", label: "Advanced", icon: "zap" },
];

export default function CoachScreen() {
  const insets = useSafeAreaInsets();
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [isStreaming, setIsStreaming] = useState(false);
  const [fitnessLevel, setFitnessLevel] = useState<FitnessLevel>("beginner");
  const [showSetup, setShowSetup] = useState(true);
  const [goals, setGoals] = useState<string[]>([]);
  const listRef = useRef<FlatList<Message>>(null);
  const isWeb = Platform.OS === "web";
  const topPadding = isWeb ? 67 : insets.top;
  const bottomPadding = isWeb ? 34 : insets.bottom;

  const GOAL_OPTIONS = ["Weight Loss", "Muscle Gain", "Endurance", "Flexibility", "Strength", "General Fitness"];

  const toggleGoal = (goal: string) => {
    setGoals((prev) =>
      prev.includes(goal) ? prev.filter((g) => g !== goal) : [...prev, goal]
    );
  };

  const startSession = () => {
    setShowSetup(false);
    const welcomeMsg: Message = {
      id: Date.now().toString(),
      role: "assistant",
      content: `Welcome! I'm your AI fitness coach. Based on your ${fitnessLevel} level${goals.length > 0 ? ` and your goals (${goals.join(", ")})` : ""}, I'll create personalized workout plans and guide you every step of the way. 

What would you like to work on today? You can ask me to:
• Create a weekly workout plan
• Explain exercises with proper form
• Suggest a diet plan
• Give tips for faster progress

Let's get started! 💪`,
    };
    setMessages([welcomeMsg]);
  };

  const sendMessage = useCallback(async (text?: string) => {
    const messageText = (text || input).trim();
    if (!messageText || isStreaming) return;

    await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setInput("");

    const userMsg: Message = {
      id: Date.now().toString() + "u",
      role: "user",
      content: messageText,
    };

    const assistantId = Date.now().toString() + "a";
    const assistantMsg: Message = {
      id: assistantId,
      role: "assistant",
      content: "",
    };

    setMessages((prev) => [...prev, userMsg, assistantMsg]);
    setIsStreaming(true);

    try {
      const conversationHistory = [...messages, userMsg].map((m) => ({
        role: m.role,
        content: m.content,
      }));

      const response = await expoFetch(`${BASE_URL}/api/workout/plan`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          fitnessLevel,
          goals,
          message: messageText,
          conversationHistory: conversationHistory.slice(-10),
        }),
      });

      if (!response.body) throw new Error("No response body");

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let accumulated = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        const chunk = decoder.decode(value, { stream: true });
        const lines = chunk.split("\n");

        for (const line of lines) {
          if (line.startsWith("data: ")) {
            const jsonStr = line.slice(6).trim();
            if (!jsonStr) continue;
            try {
              const parsed = JSON.parse(jsonStr);
              if (parsed.content) {
                accumulated += parsed.content;
                setMessages((prev) =>
                  prev.map((m) =>
                    m.id === assistantId ? { ...m, content: accumulated } : m
                  )
                );
              }
              if (parsed.done) break;
            } catch {}
          }
        }
      }
    } catch (err) {
      setMessages((prev) =>
        prev.map((m) =>
          m.id === assistantId
            ? { ...m, content: "Sorry, I couldn't generate a response. Please try again." }
            : m
        )
      );
    } finally {
      setIsStreaming(false);
      await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    }
  }, [input, messages, fitnessLevel, goals, isStreaming]);

  const renderMessage = ({ item }: { item: Message }) => {
    const isUser = item.role === "user";
    return (
      <View style={[styles.messageRow, isUser ? styles.messageRowUser : styles.messageRowAssistant]}>
        {!isUser && (
          <View style={styles.botAvatar}>
            <MaterialCommunityIcons name="dumbbell" size={16} color={Colors.primary} />
          </View>
        )}
        <View style={[styles.bubble, isUser ? styles.bubbleUser : styles.bubbleAssistant]}>
          <Text style={[styles.bubbleText, isUser ? styles.bubbleTextUser : styles.bubbleTextAssistant]}>
            {item.content || (isStreaming ? "▊" : "")}
          </Text>
        </View>
      </View>
    );
  };

  if (showSetup) {
    return (
      <View style={[styles.container, { paddingTop: topPadding }]}>
        <ScrollView
          contentContainerStyle={styles.setupScroll}
          showsVerticalScrollIndicator={false}
        >
          <View style={styles.setupHeader}>
            <View style={styles.coachIcon}>
              <MaterialCommunityIcons name="dumbbell" size={32} color={Colors.primary} />
            </View>
            <Text style={styles.setupTitle}>AI Fitness Coach</Text>
            <Text style={styles.setupSubtitle}>
              Get personalized workout plans that adapt as you progress with real-time AI coaching
            </Text>
          </View>

          <Text style={styles.sectionLabel}>Your Fitness Level</Text>
          <View style={styles.levelGrid}>
            {LEVEL_OPTIONS.map((opt) => (
              <Pressable
                key={opt.value}
                style={[styles.levelCard, fitnessLevel === opt.value && styles.levelCardActive]}
                onPress={() => setFitnessLevel(opt.value)}
              >
                <Feather
                  name={opt.icon as any}
                  size={22}
                  color={fitnessLevel === opt.value ? Colors.primary : Colors.textSecondary}
                />
                <Text style={[styles.levelText, fitnessLevel === opt.value && styles.levelTextActive]}>
                  {opt.label}
                </Text>
              </Pressable>
            ))}
          </View>

          <Text style={styles.sectionLabel}>Your Goals (optional)</Text>
          <View style={styles.goalGrid}>
            {GOAL_OPTIONS.map((goal) => (
              <Pressable
                key={goal}
                style={[styles.goalChip, goals.includes(goal) && styles.goalChipActive]}
                onPress={() => toggleGoal(goal)}
              >
                <Text style={[styles.goalChipText, goals.includes(goal) && styles.goalChipTextActive]}>
                  {goal}
                </Text>
              </Pressable>
            ))}
          </View>

          <Pressable
            style={({ pressed }) => [styles.startBtn, pressed && { opacity: 0.85 }]}
            onPress={startSession}
          >
            <MaterialCommunityIcons name="dumbbell" size={20} color="#fff" />
            <Text style={styles.startBtnText}>Start Coaching Session</Text>
          </Pressable>
        </ScrollView>
      </View>
    );
  }

  return (
    <KeyboardAvoidingView
      style={[styles.container, { paddingTop: topPadding }]}
      behavior={Platform.OS === "ios" ? "padding" : undefined}
      keyboardVerticalOffset={0}
    >
      <View style={styles.chatHeader}>
        <Pressable onPress={() => setShowSetup(true)} style={styles.backBtn}>
          <Feather name="arrow-left" size={20} color={Colors.textPrimary} />
        </Pressable>
        <View style={styles.chatHeaderCenter}>
          <Text style={styles.chatHeaderTitle}>AI Coach</Text>
          <View style={styles.levelBadge}>
            <Text style={styles.levelBadgeText}>{fitnessLevel}</Text>
          </View>
        </View>
        <Pressable
          onPress={() => {
            setMessages([]);
            setShowSetup(true);
          }}
          style={styles.resetBtn}
        >
          <Feather name="refresh-cw" size={18} color={Colors.textSecondary} />
        </Pressable>
      </View>

      <FlatList
        ref={listRef}
        data={messages}
        keyExtractor={(item) => item.id}
        renderItem={renderMessage}
        contentContainerStyle={[styles.chatList, { paddingBottom: bottomPadding + 80 }]}
        showsVerticalScrollIndicator={false}
        onContentSizeChange={() => listRef.current?.scrollToEnd({ animated: true })}
        inverted={false}
        ListFooterComponent={
          messages.length > 0 ? (
            <View style={styles.quickPromptsContainer}>
              <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.quickPromptScroll}>
                {QUICK_PROMPTS.map((prompt) => (
                  <Pressable
                    key={prompt}
                    style={styles.quickChip}
                    onPress={() => sendMessage(prompt)}
                    disabled={isStreaming}
                  >
                    <Text style={styles.quickChipText}>{prompt}</Text>
                  </Pressable>
                ))}
              </ScrollView>
            </View>
          ) : null
        }
      />

      <View style={[styles.inputContainer, { paddingBottom: bottomPadding + (isWeb ? 84 : 16) }]}>
        <TextInput
          style={styles.chatInput}
          value={input}
          onChangeText={setInput}
          placeholder="Ask your coach..."
          placeholderTextColor={Colors.textTertiary}
          multiline
          maxLength={500}
          onSubmitEditing={() => sendMessage()}
          blurOnSubmit={false}
        />
        <Pressable
          style={[styles.sendBtn, (!input.trim() || isStreaming) && styles.sendBtnDisabled]}
          onPress={() => sendMessage()}
          disabled={!input.trim() || isStreaming}
        >
          {isStreaming ? (
            <ActivityIndicator size="small" color="#fff" />
          ) : (
            <Feather name="send" size={18} color="#fff" />
          )}
        </Pressable>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  setupScroll: {
    padding: 20,
    paddingBottom: Platform.OS === "web" ? 34 + 84 : 100,
  },
  setupHeader: {
    alignItems: "center",
    paddingVertical: 24,
    gap: 12,
  },
  coachIcon: {
    width: 72,
    height: 72,
    borderRadius: 36,
    backgroundColor: Colors.primary + "20",
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 2,
    borderColor: Colors.primary + "40",
  },
  setupTitle: {
    fontSize: 28,
    fontFamily: "Inter_700Bold",
    color: Colors.textPrimary,
    letterSpacing: -0.5,
  },
  setupSubtitle: {
    fontSize: 15,
    fontFamily: "Inter_400Regular",
    color: Colors.textSecondary,
    textAlign: "center",
    lineHeight: 22,
    paddingHorizontal: 20,
  },
  sectionLabel: {
    fontSize: 13,
    fontFamily: "Inter_600SemiBold",
    color: Colors.textSecondary,
    letterSpacing: 0.5,
    textTransform: "uppercase",
    marginBottom: 12,
    marginTop: 24,
  },
  levelGrid: {
    flexDirection: "row",
    gap: 10,
  },
  levelCard: {
    flex: 1,
    backgroundColor: Colors.surface,
    borderRadius: 16,
    padding: 16,
    alignItems: "center",
    gap: 8,
    borderWidth: 1,
    borderColor: Colors.surfaceBorder,
  },
  levelCardActive: {
    backgroundColor: Colors.primary + "15",
    borderColor: Colors.primary,
  },
  levelText: {
    fontSize: 13,
    fontFamily: "Inter_600SemiBold",
    color: Colors.textSecondary,
  },
  levelTextActive: {
    color: Colors.primary,
  },
  goalGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 8,
  },
  goalChip: {
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 20,
    backgroundColor: Colors.surface,
    borderWidth: 1,
    borderColor: Colors.surfaceBorder,
  },
  goalChipActive: {
    backgroundColor: Colors.primary + "20",
    borderColor: Colors.primary,
  },
  goalChipText: {
    fontSize: 14,
    fontFamily: "Inter_500Medium",
    color: Colors.textSecondary,
  },
  goalChipTextActive: {
    color: Colors.primary,
  },
  startBtn: {
    backgroundColor: Colors.primary,
    borderRadius: 16,
    paddingVertical: 18,
    alignItems: "center",
    justifyContent: "center",
    flexDirection: "row",
    gap: 10,
    marginTop: 32,
    shadowColor: Colors.primary,
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.4,
    shadowRadius: 16,
    elevation: 8,
  },
  startBtnText: {
    fontSize: 17,
    fontFamily: "Inter_700Bold",
    color: "#fff",
  },
  chatHeader: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: Colors.surfaceBorder,
  },
  backBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: Colors.surface,
    alignItems: "center",
    justifyContent: "center",
  },
  chatHeaderCenter: {
    flex: 1,
    alignItems: "center",
    flexDirection: "row",
    justifyContent: "center",
    gap: 10,
  },
  chatHeaderTitle: {
    fontSize: 17,
    fontFamily: "Inter_700Bold",
    color: Colors.textPrimary,
  },
  levelBadge: {
    backgroundColor: Colors.primary + "20",
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 10,
  },
  levelBadgeText: {
    fontSize: 11,
    fontFamily: "Inter_600SemiBold",
    color: Colors.primary,
    textTransform: "capitalize",
  },
  resetBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: Colors.surface,
    alignItems: "center",
    justifyContent: "center",
  },
  chatList: {
    paddingHorizontal: 16,
    paddingTop: 16,
  },
  messageRow: {
    flexDirection: "row",
    marginBottom: 12,
    maxWidth: "85%",
  },
  messageRowUser: {
    alignSelf: "flex-end",
    flexDirection: "row-reverse",
  },
  messageRowAssistant: {
    alignSelf: "flex-start",
  },
  botAvatar: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: Colors.primary + "20",
    alignItems: "center",
    justifyContent: "center",
    marginRight: 8,
    flexShrink: 0,
    alignSelf: "flex-end",
  },
  bubble: {
    padding: 14,
    borderRadius: 18,
    maxWidth: "100%",
  },
  bubbleUser: {
    backgroundColor: Colors.primary,
    borderBottomRightRadius: 4,
  },
  bubbleAssistant: {
    backgroundColor: Colors.surface,
    borderWidth: 1,
    borderColor: Colors.surfaceBorder,
    borderBottomLeftRadius: 4,
  },
  bubbleText: {
    fontSize: 15,
    lineHeight: 22,
  },
  bubbleTextUser: {
    color: "#fff",
    fontFamily: "Inter_400Regular",
  },
  bubbleTextAssistant: {
    color: Colors.textPrimary,
    fontFamily: "Inter_400Regular",
  },
  quickPromptsContainer: {
    marginTop: 8,
  },
  quickPromptScroll: {
    marginBottom: 8,
  },
  quickChip: {
    backgroundColor: Colors.surface,
    borderRadius: 20,
    paddingHorizontal: 14,
    paddingVertical: 10,
    marginRight: 8,
    borderWidth: 1,
    borderColor: Colors.surfaceBorder,
  },
  quickChipText: {
    fontSize: 13,
    fontFamily: "Inter_400Regular",
    color: Colors.textSecondary,
  },
  inputContainer: {
    flexDirection: "row",
    alignItems: "flex-end",
    gap: 10,
    paddingHorizontal: 16,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: Colors.surfaceBorder,
    backgroundColor: Colors.background,
  },
  chatInput: {
    flex: 1,
    backgroundColor: Colors.surface,
    borderRadius: 24,
    paddingHorizontal: 18,
    paddingVertical: 12,
    fontSize: 15,
    fontFamily: "Inter_400Regular",
    color: Colors.textPrimary,
    maxHeight: 100,
    borderWidth: 1,
    borderColor: Colors.surfaceBorder,
  },
  sendBtn: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: Colors.primary,
    alignItems: "center",
    justifyContent: "center",
    shadowColor: Colors.primary,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 4,
  },
  sendBtnDisabled: {
    opacity: 0.4,
    shadowOpacity: 0,
  },
});
