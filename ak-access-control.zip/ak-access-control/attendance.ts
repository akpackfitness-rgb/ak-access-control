import { Router, type IRouter } from "express";
import { randomUUID } from "crypto";
import { normalizeMember, sheetsGet } from "../lib/sheets.js";
import {
  insertAttendance,
  getAttendanceByDate,
  getTodayEntryForMember,
  getTodayExitForMember,
  getAvailableDates,
} from "../lib/db.js";

const router: IRouter = Router();

function todayKey() {
  return new Date().toISOString().slice(0, 10);
}

// POST /api/attendance — check in or out a member
router.post("/attendance", async (req, res) => {
  try {
    const { membershipId, type } = req.body as { membershipId: string; type: "entry" | "exit" };

    if (!membershipId || !type) {
      res.status(400).json({ error: "membershipId and type are required" });
      return;
    }

    const dateKey = todayKey();

    // --- Validation ---
    const existingEntry = await getTodayEntryForMember(membershipId, dateKey);
    const existingExit = await getTodayExitForMember(membershipId, dateKey);

    if (type === "entry") {
      if (existingEntry) {
        res.status(409).json({
          error: "ALREADY_CHECKED_IN",
          message: `${existingEntry.member_name} has already checked in today. Cannot check in twice.`,
        });
        return;
      }
    }

    if (type === "exit") {
      if (!existingEntry) {
        res.status(409).json({
          error: "NO_ENTRY_FOUND",
          message: "Cannot check out — no check-in found for today. Please check in first.",
        });
        return;
      }
      if (existingExit && existingExit.timestamp > existingEntry.timestamp) {
        res.status(409).json({
          error: "ALREADY_CHECKED_OUT",
          message: `This member has already checked out today.`,
        });
        return;
      }
    }

    // --- Fetch member ---
    const memberRaw = await sheetsGet({ action: "getMemberById", membershipId });
    if (!memberRaw || memberRaw.error || !memberRaw["Client Name"]) {
      res.status(404).json({ error: "Member not found" });
      return;
    }
    const member = normalizeMember(memberRaw);

    const record = {
      id: randomUUID(),
      membershipId: member.membershipId,
      memberName: member.name,
      package: member.package,
      type,
      timestamp: new Date().toISOString(),
      status: member.status,
      daysUntilExpiry: member.daysUntilExpiry,
    };

    await insertAttendance(record);

    res.json(record);
  } catch (err) {
    console.error("Error logging attendance:", err);
    res.status(500).json({ error: "Failed to log attendance" });
  }
});

// GET /api/attendance?date=YYYY-MM-DD&limit=N
router.get("/attendance", async (req, res) => {
  try {
    const dateKey = typeof req.query.date === "string" ? req.query.date : todayKey();
    const limit = req.query.limit ? parseInt(String(req.query.limit)) : 100;

    const rows = await getAttendanceByDate(dateKey, limit);

    const logs = rows.map((r: any) => ({
      id: r.id,
      membershipId: r.membership_id,
      memberName: r.member_name,
      package: r.package || "",
      type: r.type as "entry" | "exit",
      timestamp: r.timestamp,
      status: r.status as "active" | "expired" | "expiring_soon",
      daysUntilExpiry: r.days_until_expiry,
    }));

    res.json(logs);
  } catch (err) {
    console.error("Error fetching attendance:", err);
    res.status(500).json({ error: "Failed to fetch attendance" });
  }
});

// GET /api/attendance/dates — available dates with records
router.get("/attendance/dates", async (_req, res) => {
  try {
    const dates = await getAvailableDates();
    res.json(dates);
  } catch (err) {
    console.error("Error fetching dates:", err);
    res.status(500).json({ error: "Failed to fetch dates" });
  }
});

export default router;
