import React, { useEffect, useState, useRef, useCallback } from "react";
import {
  View,
  Text,
  FlatList,
  StyleSheet,
  RefreshControl,
  Animated,
  Platform,
  Pressable,
  Modal,
  Share,
  ActivityIndicator,
  ScrollView,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Feather, MaterialCommunityIcons } from "@expo/vector-icons";
import Colors from "@/constants/colors";

const BASE_URL = process.env.EXPO_PUBLIC_DOMAIN
  ? `https://${process.env.EXPO_PUBLIC_DOMAIN}`
  : "";

type AttendanceLog = {
  id: string;
  membershipId: string;
  memberName: string;
  package: string;
  type: "entry" | "exit";
  timestamp: string;
  status: "active" | "expired" | "expiring_soon";
  daysUntilExpiry: number;
};

type Member = {
  membershipId: string;
  name: string;
  phone: string;
  email: string;
  package: string;
  startDate: string;
  expiryDate: string;
  status: "active" | "expired" | "expiring_soon";
  daysUntilExpiry: number;
};

function todayKey() {
  return new Date().toISOString().slice(0, 10);
}

function formatDateKey(key: string) {
  if (!key) return "";
  const d = new Date(key + "T00:00:00");
  if (key === todayKey()) return "Today";
  return d.toLocaleDateString("en-IN", { weekday: "short", day: "numeric", month: "short", year: "numeric" });
}

function getStatusColor(status: string) {
  if (status === "expired") return Colors.danger;
  if (status === "expiring_soon") return Colors.warning;
  return Colors.success;
}

function getStatusLabel(status: string, days: number) {
  if (status === "expired") return `Expired`;
  if (status === "expiring_soon") return `${days}d left`;
  return "Active";
}

function formatTime(timestamp: string) {
  try {
    return new Date(timestamp).toLocaleTimeString("en-IN", {
      hour: "2-digit", minute: "2-digit", hour12: true,
    });
  } catch { return ""; }
}

function LogCard({
  item,
  isNew,
  onPress,
}: {
  item: AttendanceLog;
  isNew: boolean;
  onPress: () => void;
}) {
  const slideAnim = useRef(new Animated.Value(isNew ? -60 : 0)).current;
  const opacityAnim = useRef(new Animated.Value(isNew ? 0 : 1)).current;
  const statusColor = getStatusColor(item.status);

  useEffect(() => {
    if (isNew) {
      Animated.parallel([
        Animated.spring(slideAnim, { toValue: 0, tension: 80, friction: 8, useNativeDriver: true }),
        Animated.timing(opacityAnim, { toValue: 1, duration: 300, useNativeDriver: true }),
      ]).start();
    }
  }, []);

  return (
    <Pressable onPress={onPress} style={({ pressed }) => pressed ? { opacity: 0.7 } : {}}>
      <Animated.View
        style={[
          styles.card,
          { borderLeftColor: statusColor, transform: [{ translateY: slideAnim }], opacity: opacityAnim },
        ]}
      >
        <View style={styles.cardLeft}>
          <View style={[styles.typeIcon, {
            backgroundColor: item.type === "entry" ? Colors.success + "20" : Colors.accent + "20",
          }]}>
            <Feather
              name={item.type === "entry" ? "log-in" : "log-out"}
              size={18}
              color={item.type === "entry" ? Colors.success : Colors.accent}
            />
          </View>
          <View style={styles.cardInfo}>
            <Text style={styles.memberName} numberOfLines={1}>{item.memberName}</Text>
            <Text style={styles.memberId}>ID: {item.membershipId}</Text>
            {item.package ? (
              <View style={styles.packageRow}>
                <MaterialCommunityIcons name="dumbbell" size={12} color={Colors.textSecondary} />
                <Text style={styles.packageText} numberOfLines={1}>{item.package}</Text>
              </View>
            ) : null}
          </View>
        </View>
        <View style={styles.cardRight}>
          <View style={[styles.statusPill, { backgroundColor: statusColor + "20" }]}>
            <Text style={[styles.statusPillText, { color: statusColor }]}>
              {getStatusLabel(item.status, item.daysUntilExpiry)}
            </Text>
          </View>
          <Text style={styles.timeText}>{formatTime(item.timestamp)}</Text>
          <Text style={styles.typeLabel}>
            {item.type === "entry" ? "IN" : "OUT"}
          </Text>
        </View>
      </Animated.View>
    </Pressable>
  );
}

function DatePickerModal({
  visible,
  dates,
  selected,
  onSelect,
  onClose,
}: {
  visible: boolean;
  dates: string[];
  selected: string;
  onSelect: (d: string) => void;
  onClose: () => void;
}) {
  return (
    <Modal transparent visible={visible} animationType="slide" onRequestClose={onClose}>
      <Pressable style={styles.datePickerOverlay} onPress={onClose}>
        <Pressable style={styles.datePickerSheet} onPress={() => {}}>
          <View style={styles.datePickerHandle} />
          <Text style={styles.datePickerTitle}>Select Date</Text>
          {dates.length === 0 ? (
            <View style={styles.datePickerEmpty}>
              <Feather name="calendar" size={32} color={Colors.textTertiary} />
              <Text style={styles.datePickerEmptyText}>No recorded dates yet</Text>
            </View>
          ) : (
            <ScrollView showsVerticalScrollIndicator={false} style={{ maxHeight: 400 }}>
              {dates.map((d) => (
                <Pressable
                  key={d}
                  style={[
                    styles.dateOption,
                    d === selected && styles.dateOptionSelected,
                  ]}
                  onPress={() => { onSelect(d); onClose(); }}
                >
                  <Feather
                    name="calendar"
                    size={16}
                    color={d === selected ? Colors.primary : Colors.textSecondary}
                  />
                  <Text style={[
                    styles.dateOptionText,
                    d === selected && styles.dateOptionTextSelected,
                  ]}>
                    {formatDateKey(d)}
                  </Text>
                  {d === selected && (
                    <Feather name="check" size={16} color={Colors.primary} style={{ marginLeft: "auto" }} />
                  )}
                </Pressable>
              ))}
            </ScrollView>
          )}
          <Pressable style={styles.datePickerClose} onPress={onClose}>
            <Text style={styles.datePickerCloseText}>Done</Text>
          </Pressable>
        </Pressable>
      </Pressable>
    </Modal>
  );
}

function MemberDetailModal({
  visible,
  membershipId,
  onClose,
}: {
  visible: boolean;
  membershipId: string | null;
  onClose: () => void;
}) {
  const [member, setMember] = useState<Member | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!visible || !membershipId) { setMember(null); return; }
    setLoading(true);
    fetch(`${BASE_URL}/api/members/${encodeURIComponent(membershipId)}`)
      .then((r) => r.ok ? r.json() : null)
      .then((data) => { setMember(data); setLoading(false); })
      .catch(() => setLoading(false));
  }, [visible, membershipId]);

  const statusColor = member ? getStatusColor(member.status) : Colors.success;

  return (
    <Modal transparent visible={visible} animationType="slide" onRequestClose={onClose}>
      <Pressable style={styles.modalOverlay} onPress={onClose}>
        <Pressable style={styles.memberModal} onPress={() => {}}>
          <View style={styles.modalHandle} />
          {loading ? (
            <View style={styles.modalLoading}>
              <ActivityIndicator color={Colors.primary} size="large" />
              <Text style={styles.loadingText}>Loading member...</Text>
            </View>
          ) : member ? (
            <>
              <View style={styles.modalHeader}>
                <Text style={styles.modalTitle}>Member Details</Text>
                <Pressable onPress={onClose} style={styles.modalCloseBtn}>
                  <Feather name="x" size={20} color={Colors.textSecondary} />
                </Pressable>
              </View>
              <View style={styles.memberHero}>
                <View style={[styles.bigAvatar, { borderColor: statusColor }]}>
                  <Text style={[styles.bigAvatarText, { color: statusColor }]}>
                    {member.name.charAt(0).toUpperCase()}
                  </Text>
                </View>
                <Text style={styles.heroName}>{member.name}</Text>
                <Text style={styles.heroId}>ID: {member.membershipId}</Text>
                <View style={[styles.heroBadge, { backgroundColor: statusColor + "20" }]}>
                  <View style={[styles.heroDot, { backgroundColor: statusColor }]} />
                  <Text style={[styles.heroBadgeText, { color: statusColor }]}>
                    {member.status === "expired"
                      ? `Expired ${Math.abs(member.daysUntilExpiry)}d ago`
                      : member.status === "expiring_soon"
                      ? `Expires in ${member.daysUntilExpiry} days`
                      : `Active · ${member.daysUntilExpiry} days left`}
                  </Text>
                </View>
              </View>
              <View style={styles.detailsCard}>
                {[
                  { icon: "package", label: "Package", value: member.package },
                  { icon: "calendar", label: "Start Date", value: member.startDate },
                  { icon: "clock", label: "Expiry Date", value: member.expiryDate },
                  ...(member.phone ? [{ icon: "phone", label: "Phone", value: member.phone }] : []),
                  ...(member.email ? [{ icon: "mail", label: "Email", value: member.email }] : []),
                ].map((row, i, arr) => (
                  <View key={row.label}>
                    <View style={styles.detailRow}>
                      <View style={styles.detailIcon}>
                        <Feather name={row.icon as any} size={15} color={Colors.primary} />
                      </View>
                      <View style={styles.detailContent}>
                        <Text style={styles.detailLabel}>{row.label}</Text>
                        <Text style={styles.detailValue}>{row.value || "—"}</Text>
                      </View>
                    </View>
                    {i < arr.length - 1 && <View style={styles.rowDivider} />}
                  </View>
                ))}
              </View>
            </>
          ) : (
            <View style={styles.modalLoading}>
              <Feather name="user-x" size={36} color={Colors.textTertiary} />
              <Text style={styles.loadingText}>Member not found</Text>
            </View>
          )}
        </Pressable>
      </Pressable>
    </Modal>
  );
}

export default function DashboardScreen() {
  const insets = useSafeAreaInsets();
  const [logs, setLogs] = useState<AttendanceLog[]>([]);
  const [refreshing, setRefreshing] = useState(false);
  const [loading, setLoading] = useState(true);
  const [newIds, setNewIds] = useState<Set<string>>(new Set());
  const [selectedDate, setSelectedDate] = useState(todayKey());
  const [availableDates, setAvailableDates] = useState<string[]>([]);
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [selectedMembershipId, setSelectedMembershipId] = useState<string | null>(null);
  const [showMemberModal, setShowMemberModal] = useState(false);
  const prevIdsRef = useRef<Set<string>>(new Set());
  const isWeb = Platform.OS === "web";
  const topPadding = isWeb ? 67 : insets.top;
  const isToday = selectedDate === todayKey();

  const entryCount = logs.filter((l) => l.type === "entry").length;
  const exitCount = logs.filter((l) => l.type === "exit").length;
  const insideNow = Math.max(0, entryCount - exitCount);

  const fetchDates = useCallback(async () => {
    try {
      const res = await fetch(`${BASE_URL}/api/attendance/dates`);
      if (res.ok) {
        const dates: string[] = await res.json();
        const today = todayKey();
        if (!dates.includes(today)) dates.unshift(today);
        setAvailableDates(dates);
      }
    } catch {}
  }, []);

  const fetchLogs = useCallback(async (isRefresh = false, date?: string) => {
    if (isRefresh) setRefreshing(true);
    const dateKey = date ?? selectedDate;
    try {
      const res = await fetch(`${BASE_URL}/api/attendance?date=${dateKey}&limit=100`);
      if (res.ok) {
        const data: AttendanceLog[] = await res.json();
        setLogs((prev) => {
          const prevIds = prevIdsRef.current;
          const incomingIds = new Set(data.map((l) => l.id));
          const newOnes = new Set([...incomingIds].filter((id) => !prevIds.has(id)));
          if (newOnes.size > 0) fetchDates();
          setNewIds(newOnes);
          prevIdsRef.current = incomingIds;
          return data;
        });
      }
    } catch (e) {
      console.error("fetchLogs error:", e);
    }
    setRefreshing(false);
    setLoading(false);
  }, [selectedDate, fetchDates]);

  useEffect(() => {
    setLoading(true);
    prevIdsRef.current = new Set();
    setNewIds(new Set());
    fetchLogs(false, selectedDate);
  }, [selectedDate]);

  useEffect(() => {
    fetchDates();
    const interval = isToday ? setInterval(() => fetchLogs(), 5000) : null;
    return () => { if (interval) clearInterval(interval); };
  }, [fetchDates, fetchLogs, isToday]);

  const handleShare = useCallback(async () => {
    try {
      const label = formatDateKey(selectedDate);
      await Share.share({
        title: "AK Pack Attendance",
        message:
          `🏋️ AK PACK ACCESS CONTROL\n${label}\n\n` +
          `Entries: ${entryCount}  |  Exits: ${exitCount}  |  Inside: ${insideNow}\n\n` +
          logs.slice(0, 10).map((l) =>
            `${l.type === "entry" ? "↘" : "↗"} ${l.memberName} (${l.membershipId}) — ${formatTime(l.timestamp)}`
          ).join("\n"),
      });
    } catch {}
  }, [logs, entryCount, exitCount, insideNow, selectedDate]);

  return (
    <View style={[styles.container, { paddingTop: topPadding }]}>
      {/* Header */}
      <View style={styles.header}>
        <View>
          <Text style={styles.title}>Live Feed</Text>
          <Text style={styles.subtitle}>
            {isToday ? "Refreshes every 5s" : "Historical view"}
          </Text>
        </View>
        <View style={styles.headerRight}>
          <Pressable style={styles.shareBtn} onPress={handleShare}>
            <Feather name="share-2" size={15} color={Colors.primary} />
          </Pressable>
          {isToday && (
            <View style={styles.liveIndicator}>
              <View style={styles.liveDot} />
              <Text style={styles.liveText}>LIVE</Text>
            </View>
          )}
        </View>
      </View>

      {/* Date picker row */}
      <Pressable style={styles.datePicker} onPress={() => setShowDatePicker(true)}>
        <Feather name="calendar" size={15} color={Colors.primary} />
        <Text style={styles.datePickerLabel}>{formatDateKey(selectedDate)}</Text>
        <Feather name="chevron-down" size={15} color={Colors.textSecondary} />
      </Pressable>

      {/* Stats */}
      <View style={styles.statsRow}>
        <View style={styles.statCard}>
          <Feather name="log-in" size={20} color={Colors.success} />
          <Text style={styles.statNumber}>{entryCount}</Text>
          <Text style={styles.statLabel}>Entries</Text>
        </View>
        <View style={styles.statCard}>
          <Feather name="log-out" size={20} color={Colors.accent} />
          <Text style={styles.statNumber}>{exitCount}</Text>
          <Text style={styles.statLabel}>Exits</Text>
        </View>
        <View style={[styles.statCard, styles.statCardHighlight]}>
          <MaterialCommunityIcons name="account-group" size={20} color={Colors.primary} />
          <Text style={[styles.statNumber, { color: Colors.primary }]}>{insideNow}</Text>
          <Text style={styles.statLabel}>Inside</Text>
        </View>
      </View>

      {loading ? (
        <View style={styles.emptyContainer}>
          <ActivityIndicator color={Colors.primary} size="large" />
          <Text style={styles.emptyText}>Loading...</Text>
        </View>
      ) : logs.length === 0 ? (
        <View style={styles.emptyContainer}>
          <Feather name="activity" size={40} color={Colors.textTertiary} />
          <Text style={styles.emptyTitle}>No activity</Text>
          <Text style={styles.emptyText}>
            {isToday ? "Check-ins will appear here in real time" : `No records for ${formatDateKey(selectedDate)}`}
          </Text>
        </View>
      ) : (
        <FlatList
          data={logs}
          keyExtractor={(item, index) => `${item.id}-${index}`}
          renderItem={({ item }) => (
            <LogCard
              item={item}
              isNew={newIds.has(item.id)}
              onPress={() => { setSelectedMembershipId(item.membershipId); setShowMemberModal(true); }}
            />
          )}
          contentContainerStyle={[styles.listContent, { paddingBottom: isWeb ? 34 + 84 : 100 }]}
          showsVerticalScrollIndicator={false}
          scrollEnabled
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={() => fetchLogs(true)}
              tintColor={Colors.primary}
            />
          }
        />
      )}

      <DatePickerModal
        visible={showDatePicker}
        dates={availableDates}
        selected={selectedDate}
        onSelect={(d) => { setSelectedDate(d); }}
        onClose={() => setShowDatePicker(false)}
      />

      <MemberDetailModal
        visible={showMemberModal}
        membershipId={selectedMembershipId}
        onClose={() => { setShowMemberModal(false); setSelectedMembershipId(null); }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-start",
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 12,
  },
  title: {
    fontSize: 28, fontWeight: "700",
    color: Colors.textPrimary, fontFamily: "Inter_700Bold", letterSpacing: -0.5,
  },
  subtitle: {
    fontSize: 13, color: Colors.textSecondary, fontFamily: "Inter_400Regular", marginTop: 2,
  },
  headerRight: { flexDirection: "row", alignItems: "center", gap: 8, marginTop: 4 },
  shareBtn: {
    width: 36, height: 36, borderRadius: 18,
    backgroundColor: Colors.primary + "18",
    alignItems: "center", justifyContent: "center",
    borderWidth: 1, borderColor: Colors.primary + "40",
  },
  liveIndicator: {
    flexDirection: "row", alignItems: "center", gap: 6,
    backgroundColor: Colors.danger + "20",
    paddingHorizontal: 12, paddingVertical: 6, borderRadius: 20,
    borderWidth: 1, borderColor: Colors.danger + "40",
  },
  liveDot: { width: 7, height: 7, borderRadius: 4, backgroundColor: Colors.danger },
  liveText: { fontSize: 11, fontFamily: "Inter_700Bold", color: Colors.danger, letterSpacing: 1 },
  datePicker: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    marginHorizontal: 20,
    marginBottom: 14,
    backgroundColor: Colors.surface,
    borderRadius: 12,
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderWidth: 1,
    borderColor: Colors.primary + "40",
  },
  datePickerLabel: {
    flex: 1,
    fontSize: 14,
    fontFamily: "Inter_600SemiBold",
    color: Colors.textPrimary,
  },
  statsRow: {
    flexDirection: "row", gap: 12, paddingHorizontal: 20, marginBottom: 14,
  },
  statCard: {
    flex: 1, backgroundColor: Colors.surface, borderRadius: 14,
    padding: 14, alignItems: "center", gap: 4,
    borderWidth: 1, borderColor: Colors.surfaceBorder,
  },
  statCardHighlight: {
    borderColor: Colors.primary + "40", backgroundColor: Colors.primary + "10",
  },
  statNumber: { fontSize: 24, fontFamily: "Inter_700Bold", color: Colors.textPrimary },
  statLabel: { fontSize: 11, fontFamily: "Inter_500Medium", color: Colors.textSecondary },
  listContent: { paddingHorizontal: 20, paddingTop: 4 },
  card: {
    backgroundColor: Colors.surface, borderRadius: 16,
    padding: 16, marginBottom: 10,
    flexDirection: "row", justifyContent: "space-between", alignItems: "center",
    borderWidth: 1, borderColor: Colors.surfaceBorder, borderLeftWidth: 4,
  },
  cardLeft: { flexDirection: "row", alignItems: "center", gap: 12, flex: 1 },
  typeIcon: { width: 42, height: 42, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  cardInfo: { gap: 3, flex: 1 },
  memberName: { fontSize: 15, fontFamily: "Inter_600SemiBold", color: Colors.textPrimary },
  memberId: { fontSize: 12, fontFamily: "Inter_400Regular", color: Colors.textSecondary, letterSpacing: 0.5 },
  packageRow: { flexDirection: "row", alignItems: "center", gap: 4 },
  packageText: { fontSize: 12, fontFamily: "Inter_400Regular", color: Colors.textSecondary },
  cardRight: { alignItems: "flex-end", gap: 4 },
  statusPill: { paddingHorizontal: 8, paddingVertical: 4, borderRadius: 8 },
  statusPillText: { fontSize: 11, fontFamily: "Inter_600SemiBold" },
  timeText: { fontSize: 13, fontFamily: "Inter_600SemiBold", color: Colors.textPrimary },
  typeLabel: { fontSize: 11, fontFamily: "Inter_700Bold", color: Colors.textSecondary, letterSpacing: 1 },
  emptyContainer: { flex: 1, alignItems: "center", justifyContent: "center", gap: 12, paddingBottom: 100 },
  emptyTitle: { fontSize: 18, fontFamily: "Inter_600SemiBold", color: Colors.textPrimary },
  emptyText: {
    fontSize: 14, fontFamily: "Inter_400Regular", color: Colors.textSecondary,
    textAlign: "center", paddingHorizontal: 40,
  },
  // Date picker modal
  datePickerOverlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.6)", justifyContent: "flex-end" },
  datePickerSheet: {
    backgroundColor: Colors.surfaceElevated,
    borderTopLeftRadius: 24, borderTopRightRadius: 24,
    paddingBottom: 34, paddingTop: 12,
    borderWidth: 1, borderColor: Colors.surfaceBorder,
  },
  datePickerHandle: {
    width: 40, height: 4, borderRadius: 2,
    backgroundColor: Colors.surfaceBorder,
    alignSelf: "center", marginBottom: 16,
  },
  datePickerTitle: {
    fontSize: 18, fontFamily: "Inter_700Bold", color: Colors.textPrimary,
    paddingHorizontal: 24, marginBottom: 12,
  },
  datePickerEmpty: { alignItems: "center", paddingVertical: 40, gap: 12 },
  datePickerEmptyText: { fontSize: 14, fontFamily: "Inter_400Regular", color: Colors.textSecondary },
  dateOption: {
    flexDirection: "row", alignItems: "center", gap: 12,
    paddingHorizontal: 24, paddingVertical: 16,
    borderBottomWidth: 1, borderBottomColor: Colors.surfaceBorder,
  },
  dateOptionSelected: { backgroundColor: Colors.primary + "12" },
  dateOptionText: { fontSize: 15, fontFamily: "Inter_500Medium", color: Colors.textPrimary, flex: 1 },
  dateOptionTextSelected: { fontFamily: "Inter_700Bold", color: Colors.primary },
  datePickerClose: {
    margin: 20, marginBottom: 4,
    backgroundColor: Colors.primary,
    borderRadius: 14, paddingVertical: 14,
    alignItems: "center",
  },
  datePickerCloseText: { fontSize: 16, fontFamily: "Inter_700Bold", color: "#fff" },
  // Member modal
  modalOverlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.7)", justifyContent: "flex-end" },
  memberModal: {
    backgroundColor: Colors.surfaceElevated,
    borderTopLeftRadius: 28, borderTopRightRadius: 28,
    paddingBottom: 40, paddingTop: 12, maxHeight: "90%",
    borderWidth: 1, borderColor: Colors.surfaceBorder,
  },
  modalHandle: {
    width: 40, height: 4, borderRadius: 2,
    backgroundColor: Colors.surfaceBorder, alignSelf: "center", marginBottom: 16,
  },
  modalHeader: {
    flexDirection: "row", justifyContent: "space-between", alignItems: "center",
    paddingHorizontal: 24, marginBottom: 20,
  },
  modalTitle: { fontSize: 18, fontFamily: "Inter_700Bold", color: Colors.textPrimary },
  modalCloseBtn: {
    width: 34, height: 34, borderRadius: 17,
    backgroundColor: Colors.surface, alignItems: "center", justifyContent: "center",
  },
  modalLoading: { alignItems: "center", justifyContent: "center", paddingVertical: 60, gap: 16 },
  loadingText: { fontSize: 15, fontFamily: "Inter_400Regular", color: Colors.textSecondary },
  memberHero: { alignItems: "center", paddingHorizontal: 24, marginBottom: 20, gap: 6 },
  bigAvatar: {
    width: 80, height: 80, borderRadius: 40,
    backgroundColor: Colors.primary + "20",
    alignItems: "center", justifyContent: "center",
    borderWidth: 2.5, marginBottom: 4,
  },
  bigAvatarText: { fontSize: 34, fontFamily: "Inter_700Bold" },
  heroName: { fontSize: 22, fontFamily: "Inter_700Bold", color: Colors.textPrimary, textAlign: "center" },
  heroId: { fontSize: 13, fontFamily: "Inter_400Regular", color: Colors.textSecondary, letterSpacing: 0.5 },
  heroBadge: {
    flexDirection: "row", alignItems: "center", gap: 6,
    paddingHorizontal: 14, paddingVertical: 8, borderRadius: 12, marginTop: 4,
  },
  heroDot: { width: 7, height: 7, borderRadius: 4 },
  heroBadgeText: { fontSize: 13, fontFamily: "Inter_600SemiBold" },
  detailsCard: {
    backgroundColor: Colors.surface, borderRadius: 16, marginHorizontal: 24,
    borderWidth: 1, borderColor: Colors.surfaceBorder, overflow: "hidden",
  },
  detailRow: { flexDirection: "row", alignItems: "center", gap: 14, paddingHorizontal: 16, paddingVertical: 14 },
  detailIcon: {
    width: 34, height: 34, borderRadius: 10,
    backgroundColor: Colors.primary + "15",
    alignItems: "center", justifyContent: "center",
  },
  detailContent: { flex: 1, gap: 2 },
  detailLabel: {
    fontSize: 11, fontFamily: "Inter_500Medium", color: Colors.textSecondary,
    textTransform: "uppercase", letterSpacing: 0.5,
  },
  detailValue: { fontSize: 15, fontFamily: "Inter_600SemiBold", color: Colors.textPrimary },
  rowDivider: { height: 1, backgroundColor: Colors.surfaceBorder, marginLeft: 64 },
});
