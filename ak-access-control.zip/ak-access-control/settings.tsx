import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Pressable,
  Switch,
  Alert,
  Platform,
  Linking,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Feather, MaterialCommunityIcons } from "@expo/vector-icons";
import Colors from "@/constants/colors";

// ─── Theme overrides using the golden-yellow palette ───────────────────────
const Theme = {
  accent: "#FBBF24",       // golden yellow (primary action)
  accentSoft: "#FEF3C7",   // light yellow background
  accentDark: "#D97706",   // deeper yellow for pressed states
  bg: "#0A0A0A",           // same as app background
  surface: "#141414",
  surfaceElevated: "#1C1C1C",
  surfaceBorder: "#2A2A2A",
  text: "#FFFFFF",
  textSecondary: "#8E8E93",
  textTertiary: "#48484A",
  danger: "#FF453A",
  success: "#30D158",
};

// ─── Types ──────────────────────────────────────────────────────────────────
type SettingRowProps = {
  icon: string;
  iconFamily?: "feather" | "mci";
  label: string;
  sublabel?: string;
  value?: string;
  isToggle?: boolean;
  toggleValue?: boolean;
  onToggle?: (val: boolean) => void;
  onPress?: () => void;
  danger?: boolean;
  showChevron?: boolean;
  accent?: boolean;
};

type SectionProps = {
  title: string;
  children: React.ReactNode;
};

// ─── Sub-components ─────────────────────────────────────────────────────────
function SectionHeader({ title }: { title: string }) {
  return (
    <Text style={styles.sectionTitle}>{title.toUpperCase()}</Text>
  );
}

function SettingRow({
  icon,
  iconFamily = "feather",
  label,
  sublabel,
  value,
  isToggle,
  toggleValue,
  onToggle,
  onPress,
  danger,
  showChevron = true,
  accent,
}: SettingRowProps) {
  const [pressed, setPressed] = useState(false);

  const iconColor = danger
    ? Theme.danger
    : accent
    ? Theme.accent
    : Theme.textSecondary;

  const labelColor = danger ? Theme.danger : Theme.text;

  const IconComponent =
    iconFamily === "mci" ? MaterialCommunityIcons : Feather;

  return (
    <Pressable
      onPress={onPress}
      onPressIn={() => setPressed(true)}
      onPressOut={() => setPressed(false)}
      style={[
        styles.row,
        pressed && !isToggle && { backgroundColor: Theme.surfaceElevated },
      ]}
      disabled={isToggle && !onPress}
    >
      {/* Icon badge */}
      <View
        style={[
          styles.iconBadge,
          {
            backgroundColor: danger
              ? "rgba(255,69,58,0.15)"
              : accent
              ? "rgba(251,191,36,0.15)"
              : Theme.surfaceElevated,
          },
        ]}
      >
        <IconComponent name={icon as any} size={17} color={iconColor} />
      </View>

      {/* Label area */}
      <View style={styles.rowContent}>
        <Text style={[styles.rowLabel, { color: labelColor }]}>{label}</Text>
        {sublabel ? (
          <Text style={styles.rowSublabel}>{sublabel}</Text>
        ) : null}
      </View>

      {/* Right side */}
      {isToggle ? (
        <Switch
          value={toggleValue}
          onValueChange={onToggle}
          trackColor={{ false: Theme.surfaceBorder, true: Theme.accent }}
          thumbColor={toggleValue ? "#fff" : Theme.textTertiary}
          ios_backgroundColor={Theme.surfaceBorder}
        />
      ) : value ? (
        <Text style={styles.rowValue}>{value}</Text>
      ) : showChevron ? (
        <Feather name="chevron-right" size={16} color={Theme.textTertiary} />
      ) : null}
    </Pressable>
  );
}

function Section({ title, children }: SectionProps) {
  return (
    <View style={styles.section}>
      <SectionHeader title={title} />
      <View style={styles.sectionCard}>{children}</View>
    </View>
  );
}

function Divider() {
  return <View style={styles.divider} />;
}

// ─── Main Screen ─────────────────────────────────────────────────────────────
export default function SettingsScreen() {
  const insets = useSafeAreaInsets();

  // Toggle states
  const [notifications, setNotifications] = useState(true);
  const [expiryAlerts, setExpiryAlerts] = useState(true);
  const [autoRefresh, setAutoRefresh] = useState(true);
  const [soundEnabled, setSoundEnabled] = useState(false);
  const [biometricLock, setBiometricLock] = useState(false);

  function handleClearCache() {
    Alert.alert(
      "Clear Cache",
      "This will clear all locally cached data. The app will re-fetch from Google Sheets on next load.",
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Clear",
          style: "destructive",
          onPress: () =>
            Alert.alert("Done", "Cache cleared successfully."),
        },
      ]
    );
  }

  function handleResetApp() {
    Alert.alert(
      "Reset App",
      "This will reset all settings to defaults. This cannot be undone.",
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Reset",
          style: "destructive",
          onPress: () =>
            Alert.alert("Reset", "App has been reset to defaults."),
        },
      ]
    );
  }

  function handleContactSupport() {
    Linking.openURL("mailto:support@akgym.com?subject=AK Access Control Support");
  }

  function handlePrivacyPolicy() {
    Linking.openURL("https://akgym.com/privacy");
  }

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      {/* ── Header ── */}
      <View style={styles.header}>
        <View>
          <Text style={styles.headerTitle}>Settings</Text>
          <Text style={styles.headerSubtitle}>AK Access Control</Text>
        </View>
        <View style={styles.headerBadge}>
          <MaterialCommunityIcons
            name="shield-check"
            size={20}
            color={Theme.accent}
          />
        </View>
      </View>

      <ScrollView
        contentContainerStyle={[
          styles.scrollContent,
          { paddingBottom: insets.bottom + 100 },
        ]}
        showsVerticalScrollIndicator={false}
      >
        {/* ── Google Sheets Config ── */}
        <Section title="Data Source">
          <SettingRow
            icon="link"
            label="Apps Script URL"
            sublabel="Google Sheets integration endpoint"
            onPress={() =>
              Alert.alert(
                "Apps Script URL",
                "Set APPS_SCRIPT_URL in your environment variables on Replit."
              )
            }
            accent
          />
          <Divider />
          <SettingRow
            icon="file-text"
            label="Sheet ID"
            sublabel="Google Sheets document ID"
            onPress={() =>
              Alert.alert(
                "Sheet ID",
                "Set GOOGLE_SHEET_ID in your environment variables on Replit."
              )
            }
            accent
          />
          <Divider />
          <SettingRow
            icon="refresh-cw"
            label="Auto Refresh"
            sublabel="Refresh live feed every 5 seconds"
            isToggle
            toggleValue={autoRefresh}
            onToggle={setAutoRefresh}
          />
        </Section>

        {/* ── Notifications ── */}
        <Section title="Notifications">
          <SettingRow
            icon="bell"
            label="Push Notifications"
            sublabel="Member check-in / check-out alerts"
            isToggle
            toggleValue={notifications}
            onToggle={setNotifications}
          />
          <Divider />
          <SettingRow
            icon="alert-triangle"
            label="Expiry Alerts"
            sublabel="Warn when memberships are expiring soon"
            isToggle
            toggleValue={expiryAlerts}
            onToggle={setExpiryAlerts}
          />
          <Divider />
          <SettingRow
            icon="volume-2"
            label="Sound on Check-In"
            sublabel="Play a sound when a member checks in"
            isToggle
            toggleValue={soundEnabled}
            onToggle={setSoundEnabled}
          />
        </Section>

        {/* ── Security ── */}
        <Section title="Security">
          <SettingRow
            icon="fingerprint"
            iconFamily="mci"
            label="Biometric Lock"
            sublabel="Require Face ID / fingerprint to open"
            isToggle
            toggleValue={biometricLock}
            onToggle={setBiometricLock}
          />
          <Divider />
          <SettingRow
            icon="lock"
            label="Change PIN"
            sublabel="Update your admin access PIN"
            onPress={() =>
              Alert.alert("Change PIN", "PIN management coming soon.")
            }
          />
          <Divider />
          <SettingRow
            icon="log-out"
            label="Sign Out"
            onPress={() =>
              Alert.alert("Sign Out", "Are you sure you want to sign out?", [
                { text: "Cancel", style: "cancel" },
                { text: "Sign Out", style: "destructive", onPress: () => {} },
              ])
            }
            danger
            showChevron={false}
          />
        </Section>

        {/* ── AI Coach ── */}
        <Section title="AI Coach">
          <SettingRow
            icon="cpu"
            label="AI Model"
            value="GPT-4o"
            showChevron={false}
          />
          <Divider />
          <SettingRow
            icon="mic"
            label="Voice Input"
            sublabel="Enable voice messages to AI coach"
            onPress={() =>
              Alert.alert("Voice Input", "Voice is enabled via Replit AI proxy.")
            }
          />
          <Divider />
          <SettingRow
            icon="trash-2"
            label="Clear Chat History"
            sublabel="Remove all AI coaching conversations"
            onPress={() =>
              Alert.alert(
                "Clear History",
                "Delete all AI coach chat history?",
                [
                  { text: "Cancel", style: "cancel" },
                  {
                    text: "Delete",
                    style: "destructive",
                    onPress: () =>
                      Alert.alert("Cleared", "Chat history deleted."),
                  },
                ]
              )
            }
            danger
          />
        </Section>

        {/* ── Storage ── */}
        <Section title="Storage & Cache">
          <SettingRow
            icon="database"
            label="Clear Cache"
            sublabel="Free up locally cached data"
            onPress={handleClearCache}
            danger
          />
          <Divider />
          <SettingRow
            icon="refresh-ccw"
            label="Reset App"
            sublabel="Restore all settings to defaults"
            onPress={handleResetApp}
            danger
          />
        </Section>

        {/* ── About ── */}
        <Section title="About">
          <SettingRow
            icon="info"
            label="Version"
            value="1.0.0"
            showChevron={false}
          />
          <Divider />
          <SettingRow
            icon="mail"
            label="Contact Support"
            onPress={handleContactSupport}
          />
          <Divider />
          <SettingRow
            icon="shield"
            label="Privacy Policy"
            onPress={handlePrivacyPolicy}
          />
        </Section>

        {/* ── Footer ── */}
        <View style={styles.footer}>
          <MaterialCommunityIcons
            name="dumbbell"
            size={18}
            color={Theme.textTertiary}
          />
          <Text style={styles.footerText}>AK Access Control · Gym Manager</Text>
        </View>
      </ScrollView>
    </View>
  );
}

// ─── Styles ──────────────────────────────────────────────────────────────────
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Theme.bg,
  },

  // Header
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 20,
    paddingTop: 16,
    paddingBottom: 12,
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: "700",
    color: Theme.text,
    letterSpacing: -0.5,
  },
  headerSubtitle: {
    fontSize: 13,
    color: Theme.accent,
    fontWeight: "500",
    marginTop: 2,
  },
  headerBadge: {
    width: 42,
    height: 42,
    borderRadius: 21,
    backgroundColor: "rgba(251,191,36,0.12)",
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
    borderColor: "rgba(251,191,36,0.25)",
  },

  // Scroll
  scrollContent: {
    paddingTop: 8,
  },

  // Section
  section: {
    marginHorizontal: 16,
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 11,
    fontWeight: "600",
    color: Theme.textTertiary,
    letterSpacing: 1.2,
    marginBottom: 8,
    marginLeft: 4,
  },
  sectionCard: {
    backgroundColor: Theme.surface,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: Theme.surfaceBorder,
    overflow: "hidden",
  },

  // Row
  row: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 13,
    minHeight: 56,
  },
  iconBadge: {
    width: 34,
    height: 34,
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "center",
    marginRight: 13,
  },
  rowContent: {
    flex: 1,
    justifyContent: "center",
  },
  rowLabel: {
    fontSize: 15,
    fontWeight: "500",
    color: Theme.text,
  },
  rowSublabel: {
    fontSize: 12,
    color: Theme.textSecondary,
    marginTop: 2,
  },
  rowValue: {
    fontSize: 14,
    color: Theme.accent,
    fontWeight: "600",
    marginRight: 4,
  },

  // Divider
  divider: {
    height: 1,
    backgroundColor: Theme.surfaceBorder,
    marginLeft: 63,
  },

  // Footer
  footer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 6,
    paddingVertical: 8,
    marginBottom: 8,
  },
  footerText: {
    fontSize: 12,
    color: Theme.textTertiary,
    fontWeight: "400",
  },
});
