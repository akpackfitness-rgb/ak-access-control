import React, { useEffect, useState, useCallback } from "react";
import {
  View,
  Text,
  FlatList,
  StyleSheet,
  RefreshControl,
  TextInput,
  Pressable,
  Platform,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Feather, MaterialCommunityIcons } from "@expo/vector-icons";
import Colors from "@/constants/colors";

const BASE_URL = process.env.EXPO_PUBLIC_DOMAIN
  ? `https://${process.env.EXPO_PUBLIC_DOMAIN}`
  : "";

type Member = {
  membershipId: string;
  name: string;
  phone: string;
  email: string;
  package: string;
  startDate: string;
  expiryDate: string;
  status: "active" | "expired" | "expiring_soon";
  daysUntilExpiry: number;
  photoUrl?: string;
};

function getStatusColor(status: string) {
  if (status === "expired") return Colors.danger;
  if (status === "expiring_soon") return Colors.warning;
  return Colors.success;
}

function getStatusLabel(status: string, days: number) {
  if (status === "expired") return `Expired ${Math.abs(days)}d ago`;
  if (status === "expiring_soon") return `Expires in ${days}d`;
  return `Active · ${days}d left`;
}

function MemberCard({ item }: { item: Member }) {
  const statusColor = getStatusColor(item.status);
  const initial = item.name ? item.name.charAt(0).toUpperCase() : "?";

  return (
    <View style={[styles.card, { borderLeftColor: statusColor }]}>
      <View style={[styles.avatar, { backgroundColor: statusColor + "20", borderColor: statusColor + "50" }]}>
        <Text style={[styles.avatarText, { color: statusColor }]}>{initial}</Text>
      </View>
      <View style={styles.cardBody}>
        <View style={styles.cardTop}>
          <Text style={styles.memberName} numberOfLines={1}>{item.name}</Text>
          <View style={[styles.statusPill, { backgroundColor: statusColor + "20" }]}>
            <View style={[styles.statusDot, { backgroundColor: statusColor }]} />
            <Text style={[styles.statusPillText, { color: statusColor }]}>
              {item.status === "expired" ? "Expired" : item.status === "expiring_soon" ? "Soon" : "Active"}
            </Text>
          </View>
        </View>
        <Text style={styles.memberId}>{item.membershipId}</Text>
        <View style={styles.cardMeta}>
          <View style={styles.metaItem}>
            <MaterialCommunityIcons name="dumbbell" size={12} color={Colors.textSecondary} />
            <Text style={styles.metaText} numberOfLines={1}>{item.package}</Text>
          </View>
          <View style={styles.metaDot} />
          <View style={styles.metaItem}>
            <Feather name="calendar" size={12} color={Colors.textSecondary} />
            <Text style={styles.metaText}>
              {item.expiryDate ? new Date(item.expiryDate).toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" }) : "—"}
            </Text>
          </View>
        </View>
        <Text style={[styles.daysText, { color: statusColor }]}>
          {getStatusLabel(item.status, item.daysUntilExpiry)}
        </Text>
        {item.phone ? (
          <View style={styles.metaItem}>
            <Feather name="phone" size={12} color={Colors.textSecondary} />
            <Text style={styles.metaText}>{item.phone}</Text>
          </View>
        ) : null}
      </View>
    </View>
  );
}

export default function MembersScreen() {
  const insets = useSafeAreaInsets();
  const [members, setMembers] = useState<Member[]>([]);
  const [filtered, setFiltered] = useState<Member[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState<"all" | "active" | "expired" | "expiring_soon">("all");
  const isWeb = Platform.OS === "web";
  const topPadding = isWeb ? 67 : insets.top;

  const fetchMembers = useCallback(async (isRefresh = false) => {
    if (isRefresh) setRefreshing(true);
    try {
      const res = await fetch(`${BASE_URL}/api/members`);
      if (res.ok) {
        const data: Member[] = await res.json();
        setMembers(data);
      }
    } catch (e) {
      console.error("fetchMembers error:", e);
    }
    setRefreshing(false);
    setLoading(false);
  }, []);

  useEffect(() => {
    fetchMembers();
  }, [fetchMembers]);

  useEffect(() => {
    let result = [...members];
    if (filter !== "all") {
      result = result.filter((m) => m.status === filter);
    }
    if (search.trim()) {
      const q = search.toLowerCase();
      result = result.filter(
        (m) =>
          (m.name || "").toLowerCase().includes(q) ||
          (m.membershipId || "").toLowerCase().includes(q) ||
          (m.package || "").toLowerCase().includes(q)
      );
    }
    result.sort((a, b) => {
      const aExpired = a.status === "expired" ? 1 : 0;
      const bExpired = b.status === "expired" ? 1 : 0;
      if (aExpired !== bExpired) return aExpired - bExpired;
      return (a.daysUntilExpiry || 0) - (b.daysUntilExpiry || 0);
    });
    setFiltered(result);
  }, [members, search, filter]);

  const activeCount = members.filter((m) => m.status === "active").length;
  const expiredCount = members.filter((m) => m.status === "expired").length;
  const expiringSoonCount = members.filter((m) => m.status === "expiring_soon").length;

  const filterOptions: Array<{ key: typeof filter; label: string; count: number }> = [
    { key: "all", label: "All", count: members.length },
    { key: "active", label: "Active", count: activeCount },
    { key: "expiring_soon", label: "Soon", count: expiringSoonCount },
    { key: "expired", label: "Expired", count: expiredCount },
  ];

  return (
    <View style={[styles.container, { paddingTop: topPadding }]}>
      <View style={styles.header}>
        <Text style={styles.title}>Members</Text>
        <Text style={styles.subtitle}>{members.length} total members</Text>
      </View>

      <View style={styles.searchBar}>
        <Feather name="search" size={16} color={Colors.textSecondary} />
        <TextInput
          style={styles.searchInput}
          value={search}
          onChangeText={setSearch}
          placeholder="Search by name or ID..."
          placeholderTextColor={Colors.textTertiary}
        />
        {search ? (
          <Pressable onPress={() => setSearch("")}>
            <Feather name="x" size={16} color={Colors.textSecondary} />
          </Pressable>
        ) : null}
      </View>

      <View style={styles.filterRow}>
        {filterOptions.map((opt) => (
          <Pressable
            key={opt.key}
            style={[styles.filterChip, filter === opt.key && styles.filterChipActive]}
            onPress={() => setFilter(opt.key)}
          >
            <Text style={[styles.filterChipText, filter === opt.key && styles.filterChipTextActive]}>
              {opt.label}
            </Text>
            <View style={[styles.filterBadge, filter === opt.key && styles.filterBadgeActive]}>
              <Text style={[styles.filterBadgeText, filter === opt.key && styles.filterBadgeTextActive]}>
                {opt.count}
              </Text>
            </View>
          </Pressable>
        ))}
      </View>

      {loading ? (
        <View style={styles.emptyContainer}>
          <Text style={styles.emptyText}>Loading members...</Text>
        </View>
      ) : filtered.length === 0 ? (
        <View style={styles.emptyContainer}>
          <Feather name="users" size={40} color={Colors.textTertiary} />
          <Text style={styles.emptyTitle}>No members found</Text>
          <Text style={styles.emptyText}>
            {search ? "Try a different search" : "Add members to your Google Sheet"}
          </Text>
        </View>
      ) : (
        <FlatList
          data={filtered}
          keyExtractor={(item) => item.membershipId}
          renderItem={({ item }) => <MemberCard item={item} />}
          contentContainerStyle={[
            styles.listContent,
            { paddingBottom: isWeb ? 34 + 84 : 100 },
          ]}
          showsVerticalScrollIndicator={false}
          scrollEnabled={filtered.length > 0}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={() => fetchMembers(true)}
              tintColor={Colors.primary}
            />
          }
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  header: {
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 16,
    gap: 2,
  },
  title: {
    fontSize: 28,
    fontWeight: "700",
    color: Colors.textPrimary,
    fontFamily: "Inter_700Bold",
    letterSpacing: -0.5,
  },
  subtitle: {
    fontSize: 13,
    color: Colors.textSecondary,
    fontFamily: "Inter_400Regular",
  },
  searchBar: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    backgroundColor: Colors.surface,
    marginHorizontal: 20,
    borderRadius: 14,
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderWidth: 1,
    borderColor: Colors.surfaceBorder,
    marginBottom: 12,
  },
  searchInput: {
    flex: 1,
    fontSize: 15,
    fontFamily: "Inter_400Regular",
    color: Colors.textPrimary,
  },
  filterRow: {
    flexDirection: "row",
    paddingHorizontal: 20,
    gap: 8,
    marginBottom: 16,
  },
  filterChip: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: Colors.surface,
    borderWidth: 1,
    borderColor: Colors.surfaceBorder,
  },
  filterChipActive: {
    backgroundColor: Colors.primary + "20",
    borderColor: Colors.primary,
  },
  filterChipText: {
    fontSize: 13,
    fontFamily: "Inter_500Medium",
    color: Colors.textSecondary,
  },
  filterChipTextActive: {
    color: Colors.primary,
  },
  filterBadge: {
    backgroundColor: Colors.surfaceBorder,
    borderRadius: 10,
    paddingHorizontal: 6,
    paddingVertical: 2,
  },
  filterBadgeActive: {
    backgroundColor: Colors.primary,
  },
  filterBadgeText: {
    fontSize: 11,
    fontFamily: "Inter_600SemiBold",
    color: Colors.textSecondary,
  },
  filterBadgeTextActive: {
    color: "#fff",
  },
  listContent: {
    paddingHorizontal: 20,
    paddingTop: 4,
  },
  card: {
    backgroundColor: Colors.surface,
    borderRadius: 16,
    padding: 16,
    marginBottom: 10,
    flexDirection: "row",
    gap: 14,
    borderWidth: 1,
    borderColor: Colors.surfaceBorder,
    borderLeftWidth: 4,
  },
  avatar: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1.5,
  },
  avatarText: {
    fontSize: 20,
    fontFamily: "Inter_700Bold",
  },
  cardBody: {
    flex: 1,
    gap: 4,
  },
  cardTop: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    gap: 8,
  },
  memberName: {
    fontSize: 16,
    fontFamily: "Inter_600SemiBold",
    color: Colors.textPrimary,
    flex: 1,
  },
  memberId: {
    fontSize: 12,
    fontFamily: "Inter_400Regular",
    color: Colors.textSecondary,
    letterSpacing: 0.5,
  },
  statusPill: {
    flexDirection: "row",
    alignItems: "center",
    gap: 5,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  statusDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
  statusPillText: {
    fontSize: 11,
    fontFamily: "Inter_600SemiBold",
  },
  cardMeta: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    marginTop: 2,
  },
  metaItem: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
  },
  metaText: {
    fontSize: 12,
    fontFamily: "Inter_400Regular",
    color: Colors.textSecondary,
  },
  metaDot: {
    width: 3,
    height: 3,
    borderRadius: 1.5,
    backgroundColor: Colors.textTertiary,
  },
  daysText: {
    fontSize: 12,
    fontFamily: "Inter_600SemiBold",
    marginTop: 2,
  },
  emptyContainer: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    gap: 12,
    paddingBottom: 100,
  },
  emptyTitle: {
    fontSize: 18,
    fontFamily: "Inter_600SemiBold",
    color: Colors.textPrimary,
  },
  emptyText: {
    fontSize: 14,
    fontFamily: "Inter_400Regular",
    color: Colors.textSecondary,
    textAlign: "center",
    paddingHorizontal: 40,
  },
});
