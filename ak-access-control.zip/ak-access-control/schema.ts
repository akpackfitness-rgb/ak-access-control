/**
 * schema.ts — Drizzle ORM schema for AK Access Control
 *
 * Tables:
 *   - members          → gym members (mirrors Google Sheets source)
 *   - attendance_logs  → entry / exit records
 *   - admin_users      → app login credentials
 *   - workout_sessions → AI coach conversation history per member
 *
 * Location: lib/db/src/schema/index.ts
 * (matches drizzle_config.ts → schema path)
 */

import { relations } from "drizzle-orm";
import {
  pgTable,
  pgEnum,
  text,
  integer,
  boolean,
  timestamp,
  date,
  serial,
  index,
  uniqueIndex,
} from "drizzle-orm/pg-core";

// ─── Enums ────────────────────────────────────────────────────────────────────

/**
 * Member membership status.
 * - active        → membership is valid
 * - expired       → membership has passed its expiry date
 * - expiring_soon → expiry is within 3 days
 */
export const memberStatusEnum = pgEnum("member_status", [
  "active",
  "expired",
  "expiring_soon",
]);

/**
 * Attendance log type — whether the member is entering or leaving.
 */
export const attendanceTypeEnum = pgEnum("attendance_type", [
  "entry",
  "exit",
]);

/**
 * Admin user roles — controls what sections of the app they can access.
 */
export const adminRoleEnum = pgEnum("admin_role", [
  "superadmin",
  "admin",
  "staff",
]);

/**
 * AI coach fitness level — set by member when using the coach tab.
 */
export const fitnessLevelEnum = pgEnum("fitness_level", [
  "beginner",
  "intermediate",
  "advanced",
]);

// ─── Members ──────────────────────────────────────────────────────────────────

/**
 * Gym members table.
 *
 * This is the local cache / source-of-truth mirror of the Google Sheets
 * "Members" tab. Synced via the Apps Script Web App integration.
 *
 * Real Google Sheet column names (from sheets.ts normalizeMember):
 *   "Membership ID"    → membershipId
 *   "Client Name"      → name
 *   "Contact No"       → phone
 *   "Email"            → email
 *   "Package Details"  → package
 *   "Created On"       → startDate
 *   "Package Validity" → expiryDate
 *   "Status"           → status (ACTIVE / EXPIRED)
 *   "Photo URL"        → photoUrl
 */
export const members = pgTable(
  "members",
  {
    /** Internal auto-increment PK */
    id: serial("id").primaryKey(),

    /**
     * Public membership ID used for check-in.
     * Google Sheet column: "Membership ID"
     */
    membershipId: text("membership_id").notNull().unique(),

    /**
     * Full name of the member.
     * Google Sheet column: "Client Name"
     */
    name: text("name").notNull(),

    /**
     * Contact phone number.
     * Google Sheet column: "Contact No"
     */
    phone: text("phone"),

    /**
     * Contact email address.
     * Google Sheet column: "Email"
     */
    email: text("email"),

    /**
     * Membership package name (e.g. "Monthly", "Quarterly", "Annual").
     * Google Sheet column: "Package Details"
     */
    package: text("package").notNull(),

    /**
     * Date membership started.
     * Google Sheet column: "Created On"
     * Format: DD-MM-YYYY (from sheet) → normalized to ISO date
     */
    startDate: date("start_date").notNull(),

    /**
     * Date membership expires.
     * Google Sheet column: "Package Validity"
     * Format: DD-MM-YYYY (from sheet) → normalized to ISO date
     */
    expiryDate: date("expiry_date").notNull(),

    /**
     * Computed membership status — derived from "Package Validity" date,
     * but can be overridden by the sheet's own "Status" column (ACTIVE/EXPIRED).
     */
    status: memberStatusEnum("status").notNull().default("active"),

    /** Days remaining until expiry (negative = already expired) */
    daysUntilExpiry: integer("days_until_expiry").notNull().default(0),

    /**
     * Optional profile photo URL.
     * Google Sheet column: "Photo URL"
     */
    photoUrl: text("photo_url"),

    /** Whether the member is currently inside the gym */
    isCheckedIn: boolean("is_checked_in").notNull().default(false),

    /** Timestamp of last sync from Google Sheets */
    lastSyncedAt: timestamp("last_synced_at", { withTimezone: true })
      .notNull()
      .defaultNow(),

    /** Record creation timestamp */
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),

    /** Record last update timestamp */
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => ({
    /** Fast lookup by membership ID (used on every check-in) */
    membershipIdIdx: uniqueIndex("members_membership_id_idx").on(
      table.membershipId
    ),
    /** Filter by status (used on Members tab) */
    statusIdx: index("members_status_idx").on(table.status),
    /** Search by name */
    nameIdx: index("members_name_idx").on(table.name),
  })
);

// ─── Attendance Logs ──────────────────────────────────────────────────────────

/**
 * Attendance logs table.
 *
 * Every entry and exit event is recorded here. This is the primary
 * data source for the Live Feed / Admin Dashboard tab.
 *
 * Also written to Google Sheets via Apps Script for backup.
 */
export const attendanceLogs = pgTable(
  "attendance_logs",
  {
    /** Unique log ID (UUID generated at time of check-in) */
    id: text("id").primaryKey(),

    /** Foreign key to members.membershipId */
    membershipId: text("membership_id").notNull(),

    /** Denormalized member name for fast display (avoid joins on list) */
    memberName: text("member_name").notNull(),

    /** Denormalized package name at time of check-in */
    package: text("package").notNull().default(""),

    /** Entry or exit */
    type: attendanceTypeEnum("type").notNull(),

    /** Exact timestamp of the event */
    timestamp: timestamp("timestamp", { withTimezone: true })
      .notNull()
      .defaultNow(),

    /** Membership status at the time of check-in */
    status: memberStatusEnum("status").notNull().default("active"),

    /** Days until expiry at the time of check-in */
    daysUntilExpiry: integer("days_until_expiry").notNull().default(0),

    /**
     * Date key (YYYY-MM-DD) for fast daily grouping queries.
     * Derived from timestamp — e.g. "2024-09-13"
     */
    dateKey: text("date_key").notNull(),
  },
  (table) => ({
    /** Primary query pattern: all logs for a given day */
    dateIdx: index("attendance_date_idx").on(table.dateKey),
    /** Used to find today's entry/exit for a specific member */
    memberDateIdx: index("attendance_member_date_idx").on(
      table.membershipId,
      table.dateKey
    ),
    /** Used to compute current occupancy (today's entries) */
    typeIdx: index("attendance_type_idx").on(table.type, table.dateKey),
  })
);

// ─── Admin Users ──────────────────────────────────────────────────────────────

/**
 * Admin users table.
 *
 * Stores credentials for staff who can log into the app.
 * Supports both PIN-based and password-based login (see login.tsx).
 */
export const adminUsers = pgTable(
  "admin_users",
  {
    id: serial("id").primaryKey(),

    /** Login username (must be unique) */
    username: text("username").notNull().unique(),

    /** Display name shown in the app */
    displayName: text("display_name").notNull(),

    /**
     * Hashed password (bcrypt).
     * Null if user logs in via PIN only.
     */
    passwordHash: text("password_hash"),

    /**
     * Hashed PIN (bcrypt, 4 digits).
     * Null if user logs in via password only.
     */
    pinHash: text("pin_hash"),

    /** Admin role controlling access level */
    role: adminRoleEnum("role").notNull().default("staff"),

    /** Whether this admin account is active */
    isActive: boolean("is_active").notNull().default(true),

    /** Timestamp of last successful login */
    lastLoginAt: timestamp("last_login_at", { withTimezone: true }),

    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),

    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => ({
    usernameIdx: uniqueIndex("admin_users_username_idx").on(table.username),
    roleIdx: index("admin_users_role_idx").on(table.role),
  })
);

// ─── Workout Sessions ─────────────────────────────────────────────────────────

/**
 * Workout sessions table.
 *
 * Stores AI coach conversation sessions per member.
 * Each session holds a JSON array of message history for the GPT context.
 */
export const workoutSessions = pgTable(
  "workout_sessions",
  {
    id: serial("id").primaryKey(),

    /**
     * Optional link to a member (null = anonymous / guest session).
     * Foreign key to members.membershipId.
     */
    membershipId: text("membership_id"),

    /** Fitness level set by the user for this session */
    fitnessLevel: fitnessLevelEnum("fitness_level"),

    /**
     * Goals selected by the user (stored as comma-separated string).
     * e.g. "weight_loss,muscle_gain,endurance"
     */
    goals: text("goals"),

    /** Days per week the user is available to train */
    daysPerWeek: integer("days_per_week"),

    /** Equipment available to the user */
    equipment: text("equipment"),

    /** Any physical limitations or injuries */
    limitations: text("limitations"),

    /**
     * Full conversation history (JSON array).
     * Format: [{ role: "user" | "assistant", content: string }]
     */
    conversationHistory: text("conversation_history")
      .notNull()
      .default("[]"),

    /** Number of messages exchanged in this session */
    messageCount: integer("message_count").notNull().default(0),

    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),

    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => ({
    membershipIdx: index("workout_sessions_membership_idx").on(
      table.membershipId
    ),
    createdAtIdx: index("workout_sessions_created_at_idx").on(table.createdAt),
  })
);

// ─── Relations ────────────────────────────────────────────────────────────────

/**
 * A member can have many attendance log entries.
 */
export const membersRelations = relations(members, ({ many }) => ({
  attendanceLogs: many(attendanceLogs),
  workoutSessions: many(workoutSessions),
}));

/**
 * Each attendance log belongs to one member.
 */
export const attendanceLogsRelations = relations(
  attendanceLogs,
  ({ one }) => ({
    member: one(members, {
      fields: [attendanceLogs.membershipId],
      references: [members.membershipId],
    }),
  })
);

/**
 * Each workout session optionally belongs to one member.
 */
export const workoutSessionsRelations = relations(
  workoutSessions,
  ({ one }) => ({
    member: one(members, {
      fields: [workoutSessions.membershipId],
      references: [members.membershipId],
    }),
  })
);

// ─── Exported Types ───────────────────────────────────────────────────────────

/** Inferred TypeScript types from the schema (for use across the monorepo) */

export type Member = typeof members.$inferSelect;
export type NewMember = typeof members.$inferInsert;

export type AttendanceLog = typeof attendanceLogs.$inferSelect;
export type NewAttendanceLog = typeof attendanceLogs.$inferInsert;

export type AdminUser = typeof adminUsers.$inferSelect;
export type NewAdminUser = typeof adminUsers.$inferInsert;

export type WorkoutSession = typeof workoutSessions.$inferSelect;
export type NewWorkoutSession = typeof workoutSessions.$inferInsert;
