import React, { useState, useRef, useCallback } from "react";
import {
  View,
  Text,
  StyleSheet,
  Pressable,
  Modal,
  Animated,
  ActivityIndicator,
  ScrollView,
  Platform,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Feather, MaterialCommunityIcons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import Colors from "@/constants/colors";

const BASE_URL = process.env.EXPO_PUBLIC_DOMAIN
  ? `https://${process.env.EXPO_PUBLIC_DOMAIN}`
  : "";

type Member = {
  membershipId: string;
  name: string;
  phone: string;
  email: string;
  package: string;
  startDate: string;
  expiryDate: string;
  status: "active" | "expired" | "expiring_soon";
  daysUntilExpiry: number;
};

type AttendanceLog = {
  id: string;
  membershipId: string;
  memberName: string;
  package: string;
  type: "entry" | "exit";
  timestamp: string;
  status: "active" | "expired" | "expiring_soon";
  daysUntilExpiry: number;
};

const KEYS = ["1","2","3","4","5","6","7","8","9","C","0","⌫"];

export default function CheckInScreen() {
  const insets = useSafeAreaInsets();
  const [membershipId, setMembershipId] = useState("");
  const [loading, setLoading] = useState(false);
  const [checkType, setCheckType] = useState<"entry" | "exit">("entry");
  const [showPopup, setShowPopup] = useState(false);
  const [member, setMember] = useState<Member | null>(null);
  const [log, setLog] = useState<AttendanceLog | null>(null);
  const [error, setError] = useState("");
  const [countdown, setCountdown] = useState(5);
  const popupOpacity = useRef(new Animated.Value(0)).current;
  const scaleAnim = useRef(new Animated.Value(0.8)).current;
  const shakeAnim = useRef(new Animated.Value(0)).current;
  const countdownRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const isWeb = Platform.OS === "web";
  const topPadding = isWeb ? 67 : insets.top;

  const shakeError = useCallback(() => {
    Animated.sequence([
      Animated.timing(shakeAnim, { toValue: 10, duration: 60, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: -10, duration: 60, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: 10, duration: 60, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: -8, duration: 60, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: 0, duration: 60, useNativeDriver: true }),
    ]).start();
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
  }, [shakeAnim]);

  const handleKey = useCallback((key: string) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    if (key === "⌫") {
      setMembershipId((prev) => prev.slice(0, -1));
      setError("");
    } else if (key === "C") {
      setMembershipId("");
      setError("");
    } else {
      setMembershipId((prev) => (prev.length < 10 ? prev + key : prev));
      setError("");
    }
  }, []);

  const closePopup = useCallback(() => {
    if (countdownRef.current) clearInterval(countdownRef.current);
    Animated.parallel([
      Animated.timing(popupOpacity, { toValue: 0, duration: 300, useNativeDriver: true }),
      Animated.spring(scaleAnim, { toValue: 0.8, useNativeDriver: true }),
    ]).start(() => {
      setShowPopup(false);
      setMember(null);
      setLog(null);
      setMembershipId("");
    });
  }, [popupOpacity, scaleAnim]);

  const startCountdown = useCallback(() => {
    setCountdown(5);
    countdownRef.current = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(countdownRef.current!);
          closePopup();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  }, [closePopup]);

  const showMemberPopup = useCallback((memberData: Member, logData: AttendanceLog) => {
    setMember(memberData);
    setLog(logData);
    setShowPopup(true);
    Animated.parallel([
      Animated.timing(popupOpacity, { toValue: 1, duration: 300, useNativeDriver: true }),
      Animated.spring(scaleAnim, { toValue: 1, tension: 100, friction: 8, useNativeDriver: true }),
    ]).start();
    startCountdown();
  }, [popupOpacity, scaleAnim, startCountdown]);

  const handleCheckIn = useCallback(async () => {
    if (!membershipId.trim()) {
      setError("Enter a Membership ID");
      shakeError();
      return;
    }
    setError("");
    setLoading(true);
    try {
      await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

      const logRes = await fetch(`${BASE_URL}/api/attendance`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ membershipId: membershipId.trim(), type: checkType }),
      });

      const logData = await logRes.json();

      if (!logRes.ok) {
        const code = logData.error;
        let msg = logData.message || "Failed to log attendance.";
        if (code === "ALREADY_CHECKED_IN") msg = `Already checked in today!\nCannot check in twice.`;
        if (code === "NO_ENTRY_FOUND") msg = `No check-in found today.\nPlease check in before checking out.`;
        if (code === "ALREADY_CHECKED_OUT") msg = `Already checked out today.`;
        setError(msg);
        shakeError();
        setLoading(false);
        return;
      }

      const memberRes = await fetch(`${BASE_URL}/api/members/${encodeURIComponent(membershipId.trim())}`);
      if (!memberRes.ok) {
        setLoading(false);
        return;
      }
      const memberData: Member = await memberRes.json();

      await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      showMemberPopup(memberData, logData as AttendanceLog);
    } catch {
      setError("Network error. Check connection and try again.");
      shakeError();
    } finally {
      setLoading(false);
    }
  }, [membershipId, checkType, showMemberPopup, shakeError]);

  const getStatusColor = (status: string) => {
    if (status === "expired") return Colors.danger;
    if (status === "expiring_soon") return Colors.warning;
    return Colors.success;
  };

  const getStatusLabel = (status: string, days: number) => {
    if (status === "expired") return `Expired ${Math.abs(days)}d ago`;
    if (status === "expiring_soon") return `Expires in ${days} day${days !== 1 ? "s" : ""}`;
    return `Active · ${days} days left`;
  };

  return (
    <View style={[styles.container, { paddingTop: topPadding }]}>
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View style={styles.header}>
          <MaterialCommunityIcons name="dumbbell" size={32} color={Colors.primary} />
          <Text style={styles.title}>AK PACK ACCESS CONTROL</Text>
        </View>

        {/* Entry / Exit toggle */}
        <View style={styles.toggleContainer}>
          <Pressable
            style={[styles.toggleBtn, checkType === "entry" && styles.toggleBtnActive]}
            onPress={() => { setCheckType("entry"); setError(""); }}
          >
            <Feather name="log-in" size={18} color={checkType === "entry" ? "#fff" : Colors.textSecondary} />
            <Text style={[styles.toggleText, checkType === "entry" && styles.toggleTextActive]}>Entry</Text>
          </Pressable>
          <Pressable
            style={[styles.toggleBtn, checkType === "exit" && styles.toggleBtnActive]}
            onPress={() => { setCheckType("exit"); setError(""); }}
          >
            <Feather name="log-out" size={18} color={checkType === "exit" ? "#fff" : Colors.textSecondary} />
            <Text style={[styles.toggleText, checkType === "exit" && styles.toggleTextActive]}>Exit</Text>
          </Pressable>
        </View>

        {/* ID display */}
        <Animated.View style={[styles.idDisplay, { transform: [{ translateX: shakeAnim }] }]}>
          <Text style={styles.idLabel}>MEMBERSHIP ID</Text>
          <Text style={[styles.idValue, !membershipId && styles.idPlaceholder]}>
            {membershipId || "· · · ·"}
          </Text>
          {error ? (
            <View style={styles.errorBox}>
              <Feather name="alert-circle" size={14} color={Colors.danger} />
              <Text style={styles.errorText}>{error}</Text>
            </View>
          ) : null}
        </Animated.View>

        {/* Keypad */}
        <View style={styles.keypad}>
          {KEYS.map((key) => {
            const isAction = key === "C" || key === "⌫";
            return (
              <Pressable
                key={key}
                style={({ pressed }) => [
                  styles.key,
                  isAction && styles.keyAction,
                  pressed && styles.keyPressed,
                ]}
                onPress={() => handleKey(key)}
              >
                <Text style={[styles.keyText, isAction && styles.keyActionText]}>{key}</Text>
              </Pressable>
            );
          })}
        </View>

        {/* Submit */}
        <Pressable
          style={({ pressed }) => [
            styles.checkBtn,
            pressed && styles.checkBtnPressed,
            loading && styles.checkBtnDisabled,
          ]}
          onPress={handleCheckIn}
          disabled={loading}
        >
          {loading ? (
            <ActivityIndicator color="#fff" />
          ) : (
            <>
              <Feather name={checkType === "entry" ? "log-in" : "log-out"} size={20} color="#fff" />
              <Text style={styles.checkBtnText}>
                {checkType === "entry" ? "Check In" : "Check Out"}
              </Text>
            </>
          )}
        </Pressable>
      </ScrollView>

      {/* Member popup */}
      <Modal transparent visible={showPopup} animationType="none" onRequestClose={closePopup}>
        <View style={styles.modalOverlay}>
          <Animated.View style={[styles.popup, { opacity: popupOpacity, transform: [{ scale: scaleAnim }] }]}>
            {member && log ? (
              <>
                <View style={styles.popupHeader}>
                  <View style={[styles.popupBadge, {
                    backgroundColor: log.type === "entry" ? Colors.success : Colors.accent,
                  }]}>
                    <Feather name={log.type === "entry" ? "log-in" : "log-out"} size={14} color="#fff" />
                    <Text style={styles.popupBadgeText}>
                      {log.type === "entry" ? "CHECKED IN" : "CHECKED OUT"}
                    </Text>
                  </View>
                  <Pressable onPress={closePopup} style={styles.popupClose}>
                    <Feather name="x" size={20} color={Colors.textSecondary} />
                  </Pressable>
                </View>

                <View style={styles.avatarRow}>
                  <View style={[styles.avatar, { borderColor: getStatusColor(member.status) }]}>
                    <Text style={[styles.avatarText, { color: getStatusColor(member.status) }]}>
                      {member.name.charAt(0).toUpperCase()}
                    </Text>
                  </View>
                </View>

                <Text style={styles.popupName}>{member.name}</Text>
                <Text style={styles.popupId}>ID: {member.membershipId}</Text>

                <View style={[styles.statusBadge, { backgroundColor: getStatusColor(member.status) + "20" }]}>
                  <View style={[styles.statusDot, { backgroundColor: getStatusColor(member.status) }]} />
                  <Text style={[styles.statusText, { color: getStatusColor(member.status) }]}>
                    {getStatusLabel(member.status, member.daysUntilExpiry)}
                  </Text>
                </View>

                <View style={styles.detailsGrid}>
                  {[
                    { label: "Package", value: member.package },
                    { label: "Expires", value: member.expiryDate },
                    ...(member.phone ? [{ label: "Phone", value: member.phone }] : []),
                  ].map((item, i, arr) => (
                    <React.Fragment key={item.label}>
                      <View style={styles.detailItem}>
                        <Text style={styles.detailLabel}>{item.label}</Text>
                        <Text style={styles.detailValue}>{item.value}</Text>
                      </View>
                      {i < arr.length - 1 && <View style={styles.detailDivider} />}
                    </React.Fragment>
                  ))}
                </View>

                <View style={styles.countdown}>
                  <Text style={styles.countdownText}>Closing in {countdown}s</Text>
                  <View style={styles.countdownTrack}>
                    <View style={[styles.countdownFill, { width: `${(countdown / 5) * 100}%` }]} />
                  </View>
                </View>
              </>
            ) : null}
          </Animated.View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  scrollContent: {
    paddingHorizontal: 24,
    paddingBottom: Platform.OS === "web" ? 34 + 84 : 100,
  },
  header: {
    alignItems: "center",
    paddingTop: 20,
    paddingBottom: 16,
    gap: 8,
  },
  title: {
    fontSize: 18,
    fontWeight: "700",
    color: Colors.textPrimary,
    fontFamily: "Inter_700Bold",
    letterSpacing: 1.5,
    textAlign: "center",
  },
  toggleContainer: {
    flexDirection: "row",
    backgroundColor: Colors.surface,
    borderRadius: 14,
    padding: 4,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: Colors.surfaceBorder,
  },
  toggleBtn: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    paddingVertical: 11,
    borderRadius: 10,
  },
  toggleBtnActive: { backgroundColor: Colors.primary },
  toggleText: { fontSize: 15, fontFamily: "Inter_600SemiBold", color: Colors.textSecondary },
  toggleTextActive: { color: "#fff" },
  idDisplay: {
    backgroundColor: Colors.surface,
    borderRadius: 16,
    padding: 20,
    marginBottom: 14,
    borderWidth: 1,
    borderColor: Colors.surfaceBorder,
    alignItems: "center",
    gap: 6,
  },
  idLabel: {
    fontSize: 11,
    fontFamily: "Inter_600SemiBold",
    color: Colors.textSecondary,
    letterSpacing: 2,
  },
  idValue: {
    fontSize: 38,
    fontFamily: "Inter_700Bold",
    color: Colors.textPrimary,
    letterSpacing: 8,
    minHeight: 48,
  },
  idPlaceholder: { color: Colors.textTertiary, letterSpacing: 6 },
  errorBox: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    backgroundColor: Colors.danger + "18",
    paddingHorizontal: 12,
    paddingVertical: 7,
    borderRadius: 10,
    marginTop: 4,
  },
  errorText: {
    fontSize: 13,
    color: Colors.danger,
    fontFamily: "Inter_500Medium",
    textAlign: "center",
    flex: 1,
  },
  keypad: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 10,
    marginBottom: 14,
    justifyContent: "center",
  },
  key: {
    width: "30%",
    aspectRatio: 1.8,
    backgroundColor: Colors.surface,
    borderRadius: 14,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
    borderColor: Colors.surfaceBorder,
  },
  keyAction: { backgroundColor: Colors.surfaceElevated },
  keyPressed: { opacity: 0.6, transform: [{ scale: 0.95 }] },
  keyText: { fontSize: 22, fontFamily: "Inter_600SemiBold", color: Colors.textPrimary },
  keyActionText: { fontSize: 16, color: Colors.textSecondary },
  checkBtn: {
    backgroundColor: Colors.primary,
    borderRadius: 16,
    paddingVertical: 18,
    alignItems: "center",
    justifyContent: "center",
    flexDirection: "row",
    gap: 10,
    shadowColor: Colors.primary,
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.4,
    shadowRadius: 16,
    elevation: 8,
  },
  checkBtnPressed: { opacity: 0.85, transform: [{ scale: 0.98 }] },
  checkBtnDisabled: { opacity: 0.6 },
  checkBtnText: { fontSize: 18, fontFamily: "Inter_700Bold", color: "#fff" },
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.85)",
    alignItems: "center",
    justifyContent: "center",
    padding: 24,
  },
  popup: {
    backgroundColor: Colors.surfaceElevated,
    borderRadius: 24,
    padding: 24,
    width: "100%",
    maxWidth: 380,
    borderWidth: 1,
    borderColor: Colors.surfaceBorder,
  },
  popupHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 20,
  },
  popupBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
  },
  popupBadgeText: { fontSize: 12, fontFamily: "Inter_700Bold", color: "#fff", letterSpacing: 0.5 },
  popupClose: {
    width: 36, height: 36, borderRadius: 18,
    backgroundColor: Colors.surface,
    alignItems: "center", justifyContent: "center",
  },
  avatarRow: { alignItems: "center", marginBottom: 14 },
  avatar: {
    width: 72, height: 72, borderRadius: 36,
    backgroundColor: Colors.primary + "20",
    alignItems: "center", justifyContent: "center",
    borderWidth: 2.5,
  },
  avatarText: { fontSize: 30, fontFamily: "Inter_700Bold" },
  popupName: {
    fontSize: 22, fontFamily: "Inter_700Bold",
    color: Colors.textPrimary, textAlign: "center", marginBottom: 4,
  },
  popupId: {
    fontSize: 13, fontFamily: "Inter_500Medium",
    color: Colors.textSecondary, textAlign: "center",
    marginBottom: 14, letterSpacing: 0.8,
  },
  statusBadge: {
    flexDirection: "row", alignItems: "center", gap: 8,
    paddingHorizontal: 16, paddingVertical: 10, borderRadius: 12,
    marginBottom: 18, alignSelf: "center",
  },
  statusDot: { width: 8, height: 8, borderRadius: 4 },
  statusText: { fontSize: 14, fontFamily: "Inter_600SemiBold" },
  detailsGrid: {
    backgroundColor: Colors.surface,
    borderRadius: 14, padding: 16,
    flexDirection: "row", flexWrap: "wrap",
    marginBottom: 18, gap: 8,
    borderWidth: 1, borderColor: Colors.surfaceBorder,
  },
  detailItem: { flex: 1, minWidth: 90, gap: 4 },
  detailDivider: { width: 1, backgroundColor: Colors.surfaceBorder, alignSelf: "stretch" },
  detailLabel: {
    fontSize: 11, fontFamily: "Inter_500Medium",
    color: Colors.textSecondary, letterSpacing: 0.5, textTransform: "uppercase",
  },
  detailValue: { fontSize: 13, fontFamily: "Inter_600SemiBold", color: Colors.textPrimary },
  countdown: { gap: 6 },
  countdownText: {
    fontSize: 12, fontFamily: "Inter_400Regular",
    color: Colors.textSecondary, textAlign: "center",
  },
  countdownTrack: {
    height: 3, backgroundColor: Colors.surfaceBorder,
    borderRadius: 2, overflow: "hidden",
  },
  countdownFill: { height: "100%", backgroundColor: Colors.primary, borderRadius: 2 },
});
