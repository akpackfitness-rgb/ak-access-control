const APPS_SCRIPT_URL = process.env.APPS_SCRIPT_URL!;

function parseSheetResponse(text: string): any {
  let cleaned = text.trim();
  const jsonpMatch = cleaned.match(/^[a-zA-Z_$][a-zA-Z0-9_$]*\s*\(([\s\S]*)\)\s*;?\s*$/);
  if (jsonpMatch) {
    cleaned = jsonpMatch[1].trim();
  }
  try {
    return JSON.parse(cleaned);
  } catch {
    console.error("sheets parse error, raw response:", text.slice(0, 300));
    throw new Error("Invalid response from Google Sheets");
  }
}

export async function sheetsGet(params: Record<string, string>): Promise<any> {
  const query = new URLSearchParams(params).toString();
  const url = `${APPS_SCRIPT_URL}?${query}`;
  const res = await fetch(url, {
    redirect: "follow",
    headers: { Accept: "application/json" },
  });
  const text = await res.text();
  return parseSheetResponse(text);
}

export async function sheetsPost(params: Record<string, string>, body: object): Promise<any> {
  const query = new URLSearchParams(params).toString();
  const url = `${APPS_SCRIPT_URL}?${query}`;
  const res = await fetch(url, {
    method: "POST",
    redirect: "follow",
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json",
    },
    body: JSON.stringify(body),
  });
  const text = await res.text();
  return parseSheetResponse(text);
}

export function getMemberStatus(expiryDateStr: string): {
  status: "active" | "expired" | "expiring_soon";
  daysUntilExpiry: number;
} {
  if (!expiryDateStr) return { status: "active", daysUntilExpiry: 0 };

  // Handle DD-MM-YYYY format from Google Sheets
  let expiry: Date;
  const ddmmyyyy = expiryDateStr.match(/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{4})$/);
  if (ddmmyyyy) {
    expiry = new Date(`${ddmmyyyy[3]}-${ddmmyyyy[2].padStart(2, "0")}-${ddmmyyyy[1].padStart(2, "0")}`);
  } else {
    expiry = new Date(expiryDateStr);
  }

  if (isNaN(expiry.getTime())) return { status: "active", daysUntilExpiry: 0 };

  const now = new Date();
  const diffMs = expiry.getTime() - now.getTime();
  const daysUntilExpiry = Math.floor(diffMs / (1000 * 60 * 60 * 24));

  if (daysUntilExpiry < 0) {
    return { status: "expired", daysUntilExpiry };
  } else if (daysUntilExpiry <= 3) {
    return { status: "expiring_soon", daysUntilExpiry };
  } else {
    return { status: "active", daysUntilExpiry };
  }
}

// Normalize a member row from the actual Apps Script column names
export function normalizeMember(row: any) {
  const expiryDate =
    row["Package Validity"] ||
    row.expiryDate || row.ExpiryDate || row["Expiry Date"] || row["expiry_date"] || "";

  const sheetStatus = (row["Status"] || row.status || "").toUpperCase();
  let { status, daysUntilExpiry } = getMemberStatus(expiryDate);

  // Trust the sheet's own Status field if present
  if (sheetStatus === "EXPIRED") {
    status = "expired";
    if (daysUntilExpiry >= 0) daysUntilExpiry = -1;
  } else if (sheetStatus === "ACTIVE" && status === "expired") {
    status = "active";
    daysUntilExpiry = 0;
  }

  return {
    membershipId:
      row["Membership ID"] || row.membershipId || row.MembershipID || row["membership_id"] || "",
    name:
      row["Client Name"] || row.name || row.Name || row.NAME || "",
    phone:
      row["Contact No"] || row.phone || row.Phone || row.PHONE || "",
    email:
      row.email || row.Email || row.EMAIL || "",
    package:
      row["Package Details"] || row.package || row.Package || row.PACKAGE || row["Package Name"] || "",
    startDate:
      row["Created On"] || row.startDate || row.StartDate || row["Start Date"] || row.start_date || "",
    expiryDate,
    photoUrl: row.photoUrl || row.PhotoURL || row["Photo URL"] || "",
    status,
    daysUntilExpiry,
  };
}
