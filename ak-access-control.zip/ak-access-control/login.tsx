import React, { useState, useRef, useCallback } from "react";
import {
  View,
  Text,
  StyleSheet,
  Pressable,
  Animated,
  ActivityIndicator,
  Platform,
  TextInput,
  KeyboardAvoidingView,
  ScrollView,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Feather, MaterialCommunityIcons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { router } from "expo-router";

// ─── Theme ───────────────────────────────────────────────────────────────────
const Theme = {
  accent: "#FBBF24",
  accentDark: "#D97706",
  accentGlow: "rgba(251,191,36,0.18)",
  accentBorder: "rgba(251,191,36,0.35)",
  bg: "#0A0A0A",
  surface: "#141414",
  surfaceElevated: "#1C1C1C",
  surfaceBorder: "#2A2A2A",
  text: "#FFFFFF",
  textSecondary: "#8E8E93",
  textTertiary: "#48484A",
  danger: "#FF453A",
  dangerSoft: "rgba(255,69,58,0.12)",
};

// ─── PIN Keypad Keys ──────────────────────────────────────────────────────────
const KEYS = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "", "0", "⌫"];
const PIN_LENGTH = 4;

// ─── Dot indicator ───────────────────────────────────────────────────────────
function PinDots({ value, shake }: { value: string; shake: Animated.Value }) {
  return (
    <Animated.View
      style={[
        styles.dotsRow,
        { transform: [{ translateX: shake }] },
      ]}
    >
      {Array.from({ length: PIN_LENGTH }).map((_, i) => {
        const filled = i < value.length;
        return (
          <View
            key={i}
            style={[
              styles.dot,
              filled && styles.dotFilled,
            ]}
          />
        );
      })}
    </Animated.View>
  );
}

// ─── Keypad Button ───────────────────────────────────────────────────────────
function KeyButton({
  label,
  onPress,
}: {
  label: string;
  onPress: () => void;
}) {
  const scale = useRef(new Animated.Value(1)).current;

  function handlePressIn() {
    Animated.spring(scale, {
      toValue: 0.88,
      useNativeDriver: true,
      speed: 50,
      bounciness: 4,
    }).start();
  }

  function handlePressOut() {
    Animated.spring(scale, {
      toValue: 1,
      useNativeDriver: true,
      speed: 30,
      bounciness: 6,
    }).start();
  }

  if (label === "") {
    return <View style={styles.keyEmpty} />;
  }

  const isDelete = label === "⌫";

  return (
    <Pressable
      onPress={onPress}
      onPressIn={handlePressIn}
      onPressOut={handlePressOut}
      style={styles.keyWrap}
    >
      <Animated.View
        style={[
          styles.key,
          isDelete && styles.keyDelete,
          { transform: [{ scale }] },
        ]}
      >
        {isDelete ? (
          <Feather name="delete" size={20} color={Theme.textSecondary} />
        ) : (
          <Text style={styles.keyLabel}>{label}</Text>
        )}
      </Animated.View>
    </Pressable>
  );
}

// ─── Main Login Screen ────────────────────────────────────────────────────────
export default function LoginScreen() {
  const insets = useSafeAreaInsets();
  const isWeb = Platform.OS === "web";

  // Mode: "pin" | "password"
  const [mode, setMode] = useState<"pin" | "password">("pin");

  // PIN state
  const [pin, setPin] = useState("");
  const shakeAnim = useRef(new Animated.Value(0)).current;

  // Password state
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);

  // Shared
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const logoScale = useRef(new Animated.Value(0.7)).current;

  // Animate logo in on mount
  React.useEffect(() => {
    Animated.parallel([
      Animated.spring(logoScale, {
        toValue: 1,
        useNativeDriver: true,
        speed: 10,
        bounciness: 8,
      }),
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 600,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  // ── Shake animation on wrong PIN ──
  const shakeError = useCallback(() => {
    Animated.sequence([
      Animated.timing(shakeAnim, { toValue: 12, duration: 60, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: -12, duration: 60, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: 10, duration: 60, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: -8, duration: 60, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: 0, duration: 60, useNativeDriver: true }),
    ]).start();
    if (Platform.OS !== "web") {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    }
  }, [shakeAnim]);

  // ── Handle PIN key press ──
  const handleKey = useCallback(
    (key: string) => {
      if (loading) return;
      setError("");

      if (Platform.OS !== "web") {
        Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
      }

      if (key === "⌫") {
        setPin((prev) => prev.slice(0, -1));
        return;
      }

      const next = pin + key;
      setPin(next);

      if (next.length === PIN_LENGTH) {
        handlePinSubmit(next);
      }
    },
    [pin, loading]
  );

  // ── Submit PIN ──
  async function handlePinSubmit(value: string) {
    setLoading(true);
    setError("");

    // Simulate auth — replace with real API call
    await new Promise((r) => setTimeout(r, 800));

    // Demo: PIN "1234" is correct
    if (value === "1234") {
      if (Platform.OS !== "web") {
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      }
      router.replace("/(tabs)");
    } else {
      shakeError();
      setError("Incorrect PIN. Please try again.");
      setPin("");
    }

    setLoading(false);
  }

  // ── Submit Password ──
  async function handlePasswordSubmit() {
    if (!username.trim() || !password.trim()) {
      setError("Please enter both username and password.");
      return;
    }

    setLoading(true);
    setError("");

    // Simulate auth — replace with real API call
    await new Promise((r) => setTimeout(r, 900));

    // Demo: admin / admin123
    if (username.trim() === "admin" && password === "admin123") {
      if (Platform.OS !== "web") {
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      }
      router.replace("/(tabs)");
    } else {
      setError("Invalid username or password.");
    }

    setLoading(false);
  }

  // ── Switch mode ──
  function toggleMode() {
    setError("");
    setPin("");
    setUsername("");
    setPassword("");
    setMode((m) => (m === "pin" ? "password" : "pin"));
  }

  return (
    <KeyboardAvoidingView
      style={{ flex: 1 }}
      behavior={Platform.OS === "ios" ? "padding" : undefined}
    >
      <ScrollView
        contentContainerStyle={[
          styles.container,
          {
            paddingTop: insets.top + (isWeb ? 20 : 0),
            paddingBottom: insets.bottom + 24,
          },
        ]}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        {/* ── Logo & Branding ── */}
        <Animated.View
          style={[
            styles.brandSection,
            { opacity: fadeAnim, transform: [{ scale: logoScale }] },
          ]}
        >
          <View style={styles.logoWrap}>
            <MaterialCommunityIcons
              name="shield-check"
              size={42}
              color={Theme.accent}
            />
          </View>
          <Text style={styles.appName}>AK Access Control</Text>
          <Text style={styles.appTagline}>Gym Attendance Manager</Text>
        </Animated.View>

        {/* ── Mode Toggle ── */}
        <Animated.View style={[styles.modeToggleWrap, { opacity: fadeAnim }]}>
          <View style={styles.modeToggle}>
            <Pressable
              style={[styles.modeBtn, mode === "pin" && styles.modeBtnActive]}
              onPress={() => mode !== "pin" && toggleMode()}
            >
              <Text
                style={[
                  styles.modeBtnText,
                  mode === "pin" && styles.modeBtnTextActive,
                ]}
              >
                PIN
              </Text>
            </Pressable>
            <Pressable
              style={[
                styles.modeBtn,
                mode === "password" && styles.modeBtnActive,
              ]}
              onPress={() => mode !== "password" && toggleMode()}
            >
              <Text
                style={[
                  styles.modeBtnText,
                  mode === "password" && styles.modeBtnTextActive,
                ]}
              >
                Password
              </Text>
            </Pressable>
          </View>
        </Animated.View>

        {/* ── PIN Mode ── */}
        {mode === "pin" && (
          <Animated.View style={[styles.pinSection, { opacity: fadeAnim }]}>
            <Text style={styles.pinPrompt}>Enter your 4-digit PIN</Text>

            <PinDots value={pin} shake={shakeAnim} />

            {/* Error */}
            {error ? (
              <View style={styles.errorRow}>
                <Feather name="alert-circle" size={13} color={Theme.danger} />
                <Text style={styles.errorText}>{error}</Text>
              </View>
            ) : null}

            {/* Keypad */}
            <View style={styles.keypad}>
              {KEYS.map((key, i) => (
                <KeyButton
                  key={i}
                  label={key}
                  onPress={() => key && handleKey(key)}
                />
              ))}
            </View>

            {/* Loading overlay on last dot */}
            {loading && (
              <ActivityIndicator
                size="small"
                color={Theme.accent}
                style={{ marginTop: 12 }}
              />
            )}
          </Animated.View>
        )}

        {/* ── Password Mode ── */}
        {mode === "password" && (
          <Animated.View style={[styles.passwordSection, { opacity: fadeAnim }]}>
            <Text style={styles.pinPrompt}>Admin Login</Text>

            {/* Username */}
            <View style={styles.inputWrap}>
              <Feather
                name="user"
                size={16}
                color={Theme.textSecondary}
                style={styles.inputIcon}
              />
              <TextInput
                style={styles.input}
                placeholder="Username"
                placeholderTextColor={Theme.textTertiary}
                value={username}
                onChangeText={(t) => {
                  setUsername(t);
                  setError("");
                }}
                autoCapitalize="none"
                autoCorrect={false}
                returnKeyType="next"
              />
            </View>

            {/* Password */}
            <View style={styles.inputWrap}>
              <Feather
                name="lock"
                size={16}
                color={Theme.textSecondary}
                style={styles.inputIcon}
              />
              <TextInput
                style={[styles.input, { flex: 1 }]}
                placeholder="Password"
                placeholderTextColor={Theme.textTertiary}
                value={password}
                onChangeText={(t) => {
                  setPassword(t);
                  setError("");
                }}
                secureTextEntry={!showPassword}
                autoCapitalize="none"
                autoCorrect={false}
                returnKeyType="done"
                onSubmitEditing={handlePasswordSubmit}
              />
              <Pressable
                onPress={() => setShowPassword((v) => !v)}
                style={styles.eyeBtn}
              >
                <Feather
                  name={showPassword ? "eye-off" : "eye"}
                  size={16}
                  color={Theme.textSecondary}
                />
              </Pressable>
            </View>

            {/* Error */}
            {error ? (
              <View style={styles.errorRow}>
                <Feather name="alert-circle" size={13} color={Theme.danger} />
                <Text style={styles.errorText}>{error}</Text>
              </View>
            ) : null}

            {/* Login Button */}
            <Pressable
              style={[styles.loginBtn, loading && { opacity: 0.7 }]}
              onPress={handlePasswordSubmit}
              disabled={loading}
            >
              {loading ? (
                <ActivityIndicator size="small" color="#000" />
              ) : (
                <>
                  <Text style={styles.loginBtnText}>Sign In</Text>
                  <Feather name="arrow-right" size={17} color="#000" />
                </>
              )}
            </Pressable>

            {/* Forgot */}
            <Pressable style={styles.forgotBtn}>
              <Text style={styles.forgotText}>Forgot password?</Text>
            </Pressable>
          </Animated.View>
        )}

        {/* ── Footer ── */}
        <View style={styles.footer}>
          <MaterialCommunityIcons
            name="dumbbell"
            size={14}
            color={Theme.textTertiary}
          />
          <Text style={styles.footerText}>
            Authorized personnel only
          </Text>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

// ─── Styles ──────────────────────────────────────────────────────────────────
const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    backgroundColor: Theme.bg,
    alignItems: "center",
    paddingHorizontal: 24,
  },

  // Brand
  brandSection: {
    alignItems: "center",
    marginTop: 40,
    marginBottom: 32,
  },
  logoWrap: {
    width: 84,
    height: 84,
    borderRadius: 28,
    backgroundColor: Theme.accentGlow,
    borderWidth: 1.5,
    borderColor: Theme.accentBorder,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 16,
    shadowColor: Theme.accent,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.35,
    shadowRadius: 20,
    elevation: 8,
  },
  appName: {
    fontSize: 26,
    fontWeight: "700",
    color: Theme.text,
    letterSpacing: -0.5,
  },
  appTagline: {
    fontSize: 13,
    color: Theme.accent,
    fontWeight: "500",
    marginTop: 4,
  },

  // Mode toggle
  modeToggleWrap: {
    width: "100%",
    alignItems: "center",
    marginBottom: 28,
  },
  modeToggle: {
    flexDirection: "row",
    backgroundColor: Theme.surface,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: Theme.surfaceBorder,
    padding: 4,
  },
  modeBtn: {
    paddingHorizontal: 28,
    paddingVertical: 9,
    borderRadius: 10,
  },
  modeBtnActive: {
    backgroundColor: Theme.accent,
  },
  modeBtnText: {
    fontSize: 14,
    fontWeight: "600",
    color: Theme.textSecondary,
  },
  modeBtnTextActive: {
    color: "#000",
  },

  // PIN section
  pinSection: {
    width: "100%",
    alignItems: "center",
  },
  pinPrompt: {
    fontSize: 15,
    color: Theme.textSecondary,
    fontWeight: "500",
    marginBottom: 24,
  },

  // Dots
  dotsRow: {
    flexDirection: "row",
    gap: 18,
    marginBottom: 16,
  },
  dot: {
    width: 16,
    height: 16,
    borderRadius: 8,
    borderWidth: 2,
    borderColor: Theme.surfaceBorder,
    backgroundColor: "transparent",
  },
  dotFilled: {
    backgroundColor: Theme.accent,
    borderColor: Theme.accent,
    shadowColor: Theme.accent,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.6,
    shadowRadius: 8,
  },

  // Error
  errorRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 5,
    marginBottom: 12,
    backgroundColor: Theme.dangerSoft,
    paddingHorizontal: 12,
    paddingVertical: 7,
    borderRadius: 8,
  },
  errorText: {
    fontSize: 13,
    color: Theme.danger,
    fontWeight: "500",
  },

  // Keypad
  keypad: {
    flexDirection: "row",
    flexWrap: "wrap",
    width: 280,
    marginTop: 8,
  },
  keyWrap: {
    width: "33.33%",
    alignItems: "center",
    marginBottom: 12,
  },
  key: {
    width: 72,
    height: 72,
    borderRadius: 36,
    backgroundColor: Theme.surfaceElevated,
    borderWidth: 1,
    borderColor: Theme.surfaceBorder,
    alignItems: "center",
    justifyContent: "center",
  },
  keyDelete: {
    backgroundColor: "transparent",
    borderColor: "transparent",
  },
  keyEmpty: {
    width: "33.33%",
  },
  keyLabel: {
    fontSize: 24,
    fontWeight: "400",
    color: Theme.text,
  },

  // Password section
  passwordSection: {
    width: "100%",
    alignItems: "center",
  },
  inputWrap: {
    width: "100%",
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: Theme.surface,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: Theme.surfaceBorder,
    paddingHorizontal: 14,
    marginBottom: 14,
    height: 54,
  },
  inputIcon: {
    marginRight: 10,
  },
  input: {
    flex: 1,
    fontSize: 15,
    color: Theme.text,
    fontWeight: "400",
  },
  eyeBtn: {
    padding: 4,
  },

  // Login button
  loginBtn: {
    width: "100%",
    height: 54,
    backgroundColor: Theme.accent,
    borderRadius: 14,
    alignItems: "center",
    justifyContent: "center",
    flexDirection: "row",
    gap: 8,
    marginTop: 4,
    shadowColor: Theme.accent,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
    elevation: 6,
  },
  loginBtnText: {
    fontSize: 16,
    fontWeight: "700",
    color: "#000",
  },
  forgotBtn: {
    marginTop: 16,
    padding: 4,
  },
  forgotText: {
    fontSize: 13,
    color: Theme.accent,
    fontWeight: "500",
  },

  // Footer
  footer: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    marginTop: 40,
  },
  footerText: {
    fontSize: 12,
    color: Theme.textTertiary,
  },
});
