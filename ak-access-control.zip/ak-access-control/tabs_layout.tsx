/**
 * app/(tabs)/_layout.tsx — AK Access Control
 *
 * Tab navigation layout for the main app.
 *
 * Tabs:
 *   1. index      → Check In   (QR / keypad check-in)
 *   2. dashboard  → Live Feed  (real-time attendance)
 *   3. members    → Members    (member list & search)
 *   4. coach      → AI Coach   (GPT fitness coach)
 *   5. settings   → Settings   (app configuration)
 *
 * Platform handling:
 *   - iOS    → BlurView tab bar (glassmorphism) + SF Symbols
 *   - Android → Solid surface tab bar + MaterialCommunityIcons / Feather
 *   - Web    → Solid surface tab bar with fixed height + Feather icons
 *
 * Theme: Golden yellow accent (#FBBF24) on dark background (#0A0A0A)
 */

import { BlurView } from "expo-blur";
import { Tabs } from "expo-router";
import { SymbolView } from "expo-symbols";
import { Feather, MaterialCommunityIcons } from "@expo/vector-icons";
import React from "react";
import { Platform, StyleSheet, View, Text } from "react-native";
import Colors from "@/constants/colors";

// ─── Brand accent — golden yellow from design theme ──────────────────────────
const ACCENT = "#FBBF24";

// ─── Tab bar heights ──────────────────────────────────────────────────────────
const TAB_BAR_HEIGHT_WEB = 84;
const TAB_BAR_HEIGHT_NATIVE = 60;

// ─── Custom Tab Bar Icon wrapper ──────────────────────────────────────────────
// Renders the icon + an active indicator dot below it
function TabIcon({
  children,
  focused,
}: {
  children: React.ReactNode;
  focused: boolean;
}) {
  return (
    <View style={tabIconStyles.wrap}>
      {children}
      {focused && <View style={tabIconStyles.dot} />}
    </View>
  );
}

const tabIconStyles = StyleSheet.create({
  wrap: {
    alignItems: "center",
    justifyContent: "center",
    gap: 4,
    paddingTop: 6,
  },
  dot: {
    width: 4,
    height: 4,
    borderRadius: 2,
    backgroundColor: ACCENT,
  },
});

// ─── Main Layout ──────────────────────────────────────────────────────────────
export default function TabLayout() {
  const isIOS = Platform.OS === "ios";
  const isWeb = Platform.OS === "web";
  const isAndroid = Platform.OS === "android";

  return (
    <Tabs
      screenOptions={{
        // Active tab uses golden yellow; inactive uses muted grey
        tabBarActiveTintColor: ACCENT,
        tabBarInactiveTintColor: Colors.textTertiary,

        // Hide the default header — each screen manages its own
        headerShown: false,

        // Label styling
        tabBarLabelStyle: {
          fontSize: 10,
          fontWeight: "600",
          letterSpacing: 0.2,
          marginBottom: isWeb ? 8 : 2,
        },

        // Tab bar container style
        tabBarStyle: {
          position: "absolute",
          backgroundColor: isIOS ? "transparent" : Colors.surface,
          borderTopWidth: isIOS ? 0 : StyleSheet.hairlineWidth,
          borderTopColor: Colors.surfaceBorder,
          elevation: 0,
          height: isWeb ? TAB_BAR_HEIGHT_WEB : TAB_BAR_HEIGHT_NATIVE,
          paddingBottom: isAndroid ? 8 : isWeb ? 16 : 0,
        },

        // Tab bar background — BlurView on iOS, solid on others
        tabBarBackground: () =>
          isIOS ? (
            <BlurView
              intensity={95}
              tint="dark"
              style={StyleSheet.absoluteFill}
            />
          ) : (
            <View
              style={[
                StyleSheet.absoluteFill,
                {
                  backgroundColor: Colors.surface,
                  borderTopWidth: StyleSheet.hairlineWidth,
                  borderTopColor: Colors.surfaceBorder,
                },
              ]}
            />
          ),
      }}
    >
      {/* ── 1. Check In ── */}
      <Tabs.Screen
        name="index"
        options={{
          title: "Check In",
          tabBarIcon: ({ color, focused }) => (
            <TabIcon focused={focused}>
              {isIOS ? (
                <SymbolView
                  name="qrcode"
                  tintColor={color}
                  size={24}
                />
              ) : (
                <Feather name="log-in" size={22} color={color} />
              )}
            </TabIcon>
          ),
        }}
      />

      {/* ── 2. Live Feed / Dashboard ── */}
      <Tabs.Screen
        name="dashboard"
        options={{
          title: "Live Feed",
          tabBarIcon: ({ color, focused }) => (
            <TabIcon focused={focused}>
              {isIOS ? (
                <SymbolView
                  name="chart.bar.fill"
                  tintColor={color}
                  size={24}
                />
              ) : (
                <Feather name="activity" size={22} color={color} />
              )}
            </TabIcon>
          ),
          // Show a live badge on the dashboard tab
          tabBarBadgeStyle: {
            backgroundColor: ACCENT,
            color: "#000",
            fontSize: 9,
            fontWeight: "700",
            minWidth: 16,
            height: 16,
            lineHeight: 16,
          },
        }}
      />

      {/* ── 3. Members ── */}
      <Tabs.Screen
        name="members"
        options={{
          title: "Members",
          tabBarIcon: ({ color, focused }) => (
            <TabIcon focused={focused}>
              {isIOS ? (
                <SymbolView
                  name="person.2.fill"
                  tintColor={color}
                  size={24}
                />
              ) : (
                <Feather name="users" size={22} color={color} />
              )}
            </TabIcon>
          ),
        }}
      />

      {/* ── 4. AI Coach ── */}
      <Tabs.Screen
        name="coach"
        options={{
          title: "AI Coach",
          tabBarIcon: ({ color, focused }) => (
            <TabIcon focused={focused}>
              {isIOS ? (
                <SymbolView
                  name="figure.run"
                  tintColor={color}
                  size={24}
                />
              ) : (
                <MaterialCommunityIcons
                  name="dumbbell"
                  size={22}
                  color={color}
                />
              )}
            </TabIcon>
          ),
        }}
      />

      {/* ── 5. Settings ── */}
      <Tabs.Screen
        name="settings"
        options={{
          title: "Settings",
          tabBarIcon: ({ color, focused }) => (
            <TabIcon focused={focused}>
              {isIOS ? (
                <SymbolView
                  name="gearshape.fill"
                  tintColor={color}
                  size={24}
                />
              ) : (
                <Feather name="settings" size={22} color={color} />
              )}
            </TabIcon>
          ),
        }}
      />
    </Tabs>
  );
}
