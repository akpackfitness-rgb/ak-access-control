import { Router, type IRouter } from "express";
import healthRouter from "./health";
import membersRouter from "./members";
import attendanceRouter from "./attendance";
import workoutRouter from "./workout";

const router: IRouter = Router();

router.use(healthRouter);
router.use(membersRouter);
router.use(attendanceRouter);
router.use(workoutRouter);

export default router;
