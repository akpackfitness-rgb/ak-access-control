import { Router, type IRouter } from "express";
import { openai } from "@workspace/integrations-openai-ai-server";

const router: IRouter = Router();

router.post("/workout/plan", async (req, res) => {
  try {
    const { fitnessLevel, goals, daysPerWeek, equipment, limitations, message, conversationHistory } = req.body;

    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache");
    res.setHeader("Connection", "keep-alive");

    const systemPrompt = `You are an expert personal trainer and fitness coach specializing in creating personalized workout plans for gym members. 

Your role is to:
- Create detailed, structured workout plans tailored to the member's fitness level, goals, and equipment
- Provide form guidance, sets, reps, rest periods and progressions
- Give instant feedback on their progress and adapt plans as they improve
- Offer motivational support and educational fitness content
- Ask clarifying questions to better understand their needs

${fitnessLevel ? `Current Fitness Level: ${fitnessLevel}` : ""}
${goals && goals.length > 0 ? `Goals: ${goals.join(", ")}` : ""}
${daysPerWeek ? `Days Available per Week: ${daysPerWeek}` : ""}
${equipment ? `Available Equipment: ${equipment}` : ""}
${limitations ? `Physical Limitations/Injuries: ${limitations}` : ""}

Format workout plans clearly with:
- Day-by-day breakdown
- Exercise name, sets × reps, rest time
- Tips for proper form
- Weekly progression notes

Be conversational, encouraging, and professional.`;

    const messages: any[] = [
      { role: "system", content: systemPrompt },
    ];

    if (conversationHistory && Array.isArray(conversationHistory)) {
      messages.push(...conversationHistory);
    }

    messages.push({ role: "user", content: message });

    const stream = await openai.chat.completions.create({
      model: "gpt-5.2",
      max_completion_tokens: 8192,
      messages,
      stream: true,
    });

    for await (const chunk of stream) {
      const content = chunk.choices[0]?.delta?.content;
      if (content) {
        res.write(`data: ${JSON.stringify({ content })}\n\n`);
      }
    }

    res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
    res.end();
  } catch (err) {
    console.error("Error generating workout plan:", err);
    res.write(`data: ${JSON.stringify({ error: "Failed to generate workout plan" })}\n\n`);
    res.end();
  }
});

export default router;
