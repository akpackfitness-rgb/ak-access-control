# Gym Attendance Manager

## Overview

Mobile app for gym attendance management with Google Sheets as the data source,
AI-powered fitness coaching, and a live admin dashboard.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **API framework**: Express 5
- **Mobile app**: Expo (React Native) with Expo Router
- **AI**: OpenAI GPT (via Replit AI Integrations — no API key needed)
- **Data storage**: Google Sheets (via Apps Script Web App)
- **Validation**: Zod, drizzle-zod
- **API codegen**: Orval (from OpenAPI spec)

## Structure

```text
artifacts-monorepo/
├── artifacts/
│   ├── api-server/         # Express API server
│   └── gym-app/            # Expo mobile app
├── lib/
│   ├── api-spec/           # OpenAPI spec + Orval codegen config
│   ├── api-client-react/   # Generated React Query hooks
│   ├── api-zod/            # Generated Zod schemas from OpenAPI
│   ├── db/                 # Drizzle ORM schema + DB connection
│   ├── integrations-openai-ai-server/  # OpenAI server-side integration
│   └── integrations-openai-ai-react/   # OpenAI React hooks
├── scripts/
├── pnpm-workspace.yaml
├── tsconfig.base.json
├── tsconfig.json
└── package.json
```

## Environment Variables

- `GOOGLE_SHEET_ID` — Google Sheets spreadsheet ID
- `APPS_SCRIPT_URL` — Google Apps Script Web App deployment URL
- `AI_INTEGRATIONS_OPENAI_BASE_URL` — Replit AI proxy base URL (auto-set)
- `AI_INTEGRATIONS_OPENAI_API_KEY` — Replit AI proxy API key (auto-set)

## Google Sheets Integration

- **NOT using Replit Google Sheets connector** (user dismissed it)
- Uses Apps Script Web App as a REST API bridge
- Sheet must have a "Members" sheet with columns:
  MembershipID, Name, Phone, Email, Package, StartDate, ExpiryDate
- Apps Script handles: getMember, getAllMembers, logAttendance, getAttendance actions

## Apps Script Setup Note

The Apps Script URL provided must support these query parameters:
- `?action=getMember&membershipId=XXX` → returns member JSON
- `?action=getAllMembers` → returns array of members
- `?action=getAttendance&limit=N` → returns attendance logs
- `POST ?action=logAttendance` with JSON body → logs entry/exit

## App Features

1. **Check In/Out Tab** — Enter Membership ID to log entry or exit. Shows 5-second member popup with details (name, package, expiry, status).

2. **Live Feed / Admin Dashboard** — Real-time attendance feed refreshing every 5 seconds. Color-coded cards: red=expired, yellow=expiring soon (<3 days), green=active. Live stats for today's entries, exits, and current occupancy.

3. **Members Tab** — All members in card design. Search and filter by status. Expired members shown in red, active in green, expiring soon in yellow.

4. **AI Coach Tab** — Personalized workout plan generator powered by GPT. Users set fitness level and goals, then chat with AI coach for workout plans, form tips, nutrition advice, and progress feedback. Streaming responses.

## Running Locally

- API server: `pnpm --filter @workspace/api-server run dev`
- Mobile app: `pnpm --filter @workspace/gym-app run dev`
- Codegen: `pnpm --filter @workspace/api-spec run codegen`

## Key Notes

- The Google Sheets integration requires the Apps Script to be deployed as a web app with "Anyone" access for public data
- OpenAI AI integration uses Replit-managed proxy — NO user API key needed, billed to Replit credits
- Attendance is logged to Google Sheets via POST to the Apps Script URL
